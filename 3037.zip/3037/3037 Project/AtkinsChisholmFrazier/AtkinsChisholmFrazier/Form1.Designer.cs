﻿namespace AtkinsChisholmFrazier
{
	partial class WinCT
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.openFileDialog2 = new System.Windows.Forms.OpenFileDialog();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.mMCToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.puicuiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jipwcuiwaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.uipchwpuiawToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ncwapuiwToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cawuipnwuicToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gastrointestinalStromalTumorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.neuroendocrinecarcinoidTumorsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hcapuiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nonHodgkinsLymphomaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thymomaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.liverToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hepatocellularCarcinomaHCCToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fibrolamellarHCCToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.secondaryLiverCancerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lungToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lungNodulesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nonsmallCellLungCancerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mesotheliomaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kidneyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.renalCellCarcinomasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.transitionalCellCarcinomasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.wilmsTumorsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.softTissueToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fibrosarcomaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dermatofibrosarcomaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fibromatosisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pelivisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.chondrosarcomaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.osteosarcomaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bladderCancerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.aboutUsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fAQToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.socialsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip2.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(77, 167);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(127, 23);
            this.progressBar1.TabIndex = 1;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.openFileDialog1_FileOk);
            // 
            // openFileDialog2
            // 
            this.openFileDialog2.FileName = "openFileDialog2";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(77, 112);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(127, 20);
            this.textBox1.TabIndex = 2;
            this.textBox1.Text = "Please upload a CT Scan";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button1.Location = new System.Drawing.Point(77, 138);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(127, 23);
            this.button1.TabIndex = 3;
            this.button1.Text = "Click to upload a Scan";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(62, 86);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(158, 20);
            this.textBox2.TabIndex = 4;
            this.textBox2.Text = "Welcome to the WinCT center!";
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // menuStrip2
            // 
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mMCToolStripMenuItem,
            this.ncwapuiwToolStripMenuItem,
            this.hcapuiToolStripMenuItem,
            this.liverToolStripMenuItem,
            this.lungToolStripMenuItem,
            this.kidneyToolStripMenuItem,
            this.softTissueToolStripMenuItem,
            this.pelivisToolStripMenuItem});
            this.menuStrip2.Location = new System.Drawing.Point(0, 0);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Size = new System.Drawing.Size(1052, 24);
            this.menuStrip2.TabIndex = 7;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // mMCToolStripMenuItem
            // 
            this.mMCToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.puicuiToolStripMenuItem,
            this.jipwcuiwaToolStripMenuItem,
            this.uipchwpuiawToolStripMenuItem});
            this.mMCToolStripMenuItem.Name = "mMCToolStripMenuItem";
            this.mMCToolStripMenuItem.Size = new System.Drawing.Size(83, 20);
            this.mMCToolStripMenuItem.Text = "Bone Lesion";
            this.mMCToolStripMenuItem.Click += new System.EventHandler(this.mMCToolStripMenuItem_Click);
            // 
            // puicuiToolStripMenuItem
            // 
            this.puicuiToolStripMenuItem.Name = "puicuiToolStripMenuItem";
            this.puicuiToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.puicuiToolStripMenuItem.Text = "Lipomas";
            // 
            // jipwcuiwaToolStripMenuItem
            // 
            this.jipwcuiwaToolStripMenuItem.Name = "jipwcuiwaToolStripMenuItem";
            this.jipwcuiwaToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.jipwcuiwaToolStripMenuItem.Text = "Giant Cell Tumors";
            // 
            // uipchwpuiawToolStripMenuItem
            // 
            this.uipchwpuiawToolStripMenuItem.Name = "uipchwpuiawToolStripMenuItem";
            this.uipchwpuiawToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.uipchwpuiawToolStripMenuItem.Text = "Ewing\'s Sarcoma";
            // 
            // ncwapuiwToolStripMenuItem
            // 
            this.ncwapuiwToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cawuipnwuicToolStripMenuItem,
            this.gastrointestinalStromalTumorToolStripMenuItem,
            this.neuroendocrinecarcinoidTumorsToolStripMenuItem});
            this.ncwapuiwToolStripMenuItem.Name = "ncwapuiwToolStripMenuItem";
            this.ncwapuiwToolStripMenuItem.Size = new System.Drawing.Size(72, 20);
            this.ncwapuiwToolStripMenuItem.Text = "Abdomen";
            // 
            // cawuipnwuicToolStripMenuItem
            // 
            this.cawuipnwuicToolStripMenuItem.Name = "cawuipnwuicToolStripMenuItem";
            this.cawuipnwuicToolStripMenuItem.Size = new System.Drawing.Size(261, 22);
            this.cawuipnwuicToolStripMenuItem.Text = "Primary Gastric Lymphoma";
            // 
            // gastrointestinalStromalTumorToolStripMenuItem
            // 
            this.gastrointestinalStromalTumorToolStripMenuItem.Name = "gastrointestinalStromalTumorToolStripMenuItem";
            this.gastrointestinalStromalTumorToolStripMenuItem.Size = new System.Drawing.Size(261, 22);
            this.gastrointestinalStromalTumorToolStripMenuItem.Text = "Gastrointestinal Stromal Tumor";
            // 
            // neuroendocrinecarcinoidTumorsToolStripMenuItem
            // 
            this.neuroendocrinecarcinoidTumorsToolStripMenuItem.Name = "neuroendocrinecarcinoidTumorsToolStripMenuItem";
            this.neuroendocrinecarcinoidTumorsToolStripMenuItem.Size = new System.Drawing.Size(261, 22);
            this.neuroendocrinecarcinoidTumorsToolStripMenuItem.Text = "Neuroendocrine (carcinoid) tumors";
            // 
            // hcapuiToolStripMenuItem
            // 
            this.hcapuiToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lyToolStripMenuItem,
            this.nonHodgkinsLymphomaToolStripMenuItem,
            this.thymomaToolStripMenuItem});
            this.hcapuiToolStripMenuItem.Name = "hcapuiToolStripMenuItem";
            this.hcapuiToolStripMenuItem.Size = new System.Drawing.Size(89, 20);
            this.hcapuiToolStripMenuItem.Text = "Mediastinum";
            this.hcapuiToolStripMenuItem.Click += new System.EventHandler(this.hcapuiToolStripMenuItem_Click);
            // 
            // lyToolStripMenuItem
            // 
            this.lyToolStripMenuItem.Name = "lyToolStripMenuItem";
            this.lyToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.lyToolStripMenuItem.Text = "Hodgkin\'s Lymphoma";
            // 
            // nonHodgkinsLymphomaToolStripMenuItem
            // 
            this.nonHodgkinsLymphomaToolStripMenuItem.Name = "nonHodgkinsLymphomaToolStripMenuItem";
            this.nonHodgkinsLymphomaToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.nonHodgkinsLymphomaToolStripMenuItem.Text = "Non-Hodgkin\'s Lymphoma";
            // 
            // thymomaToolStripMenuItem
            // 
            this.thymomaToolStripMenuItem.Name = "thymomaToolStripMenuItem";
            this.thymomaToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.thymomaToolStripMenuItem.Text = "Thymoma";
            // 
            // liverToolStripMenuItem
            // 
            this.liverToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hepatocellularCarcinomaHCCToolStripMenuItem,
            this.fibrolamellarHCCToolStripMenuItem,
            this.secondaryLiverCancerToolStripMenuItem});
            this.liverToolStripMenuItem.Name = "liverToolStripMenuItem";
            this.liverToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.liverToolStripMenuItem.Text = "Liver";
            // 
            // hepatocellularCarcinomaHCCToolStripMenuItem
            // 
            this.hepatocellularCarcinomaHCCToolStripMenuItem.Name = "hepatocellularCarcinomaHCCToolStripMenuItem";
            this.hepatocellularCarcinomaHCCToolStripMenuItem.Size = new System.Drawing.Size(248, 22);
            this.hepatocellularCarcinomaHCCToolStripMenuItem.Text = "Hepatocellular Carcinoma (HCC)";
            // 
            // fibrolamellarHCCToolStripMenuItem
            // 
            this.fibrolamellarHCCToolStripMenuItem.Name = "fibrolamellarHCCToolStripMenuItem";
            this.fibrolamellarHCCToolStripMenuItem.Size = new System.Drawing.Size(248, 22);
            this.fibrolamellarHCCToolStripMenuItem.Text = "Fibrolamellar HCC";
            // 
            // secondaryLiverCancerToolStripMenuItem
            // 
            this.secondaryLiverCancerToolStripMenuItem.Name = "secondaryLiverCancerToolStripMenuItem";
            this.secondaryLiverCancerToolStripMenuItem.Size = new System.Drawing.Size(248, 22);
            this.secondaryLiverCancerToolStripMenuItem.Text = "Secondary Liver Cancer";
            // 
            // lungToolStripMenuItem
            // 
            this.lungToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lungNodulesToolStripMenuItem,
            this.nonsmallCellLungCancerToolStripMenuItem,
            this.mesotheliomaToolStripMenuItem});
            this.lungToolStripMenuItem.Name = "lungToolStripMenuItem";
            this.lungToolStripMenuItem.Size = new System.Drawing.Size(46, 20);
            this.lungToolStripMenuItem.Text = "Lung";
            // 
            // lungNodulesToolStripMenuItem
            // 
            this.lungNodulesToolStripMenuItem.Name = "lungNodulesToolStripMenuItem";
            this.lungNodulesToolStripMenuItem.Size = new System.Drawing.Size(223, 22);
            this.lungNodulesToolStripMenuItem.Text = "Lung Nodules";
            // 
            // nonsmallCellLungCancerToolStripMenuItem
            // 
            this.nonsmallCellLungCancerToolStripMenuItem.Name = "nonsmallCellLungCancerToolStripMenuItem";
            this.nonsmallCellLungCancerToolStripMenuItem.Size = new System.Drawing.Size(223, 22);
            this.nonsmallCellLungCancerToolStripMenuItem.Text = "Non-small Cell Lung Cancer";
            // 
            // mesotheliomaToolStripMenuItem
            // 
            this.mesotheliomaToolStripMenuItem.Name = "mesotheliomaToolStripMenuItem";
            this.mesotheliomaToolStripMenuItem.Size = new System.Drawing.Size(223, 22);
            this.mesotheliomaToolStripMenuItem.Text = "Mesothelioma";
            // 
            // kidneyToolStripMenuItem
            // 
            this.kidneyToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.renalCellCarcinomasToolStripMenuItem,
            this.transitionalCellCarcinomasToolStripMenuItem,
            this.wilmsTumorsToolStripMenuItem});
            this.kidneyToolStripMenuItem.Name = "kidneyToolStripMenuItem";
            this.kidneyToolStripMenuItem.Size = new System.Drawing.Size(55, 20);
            this.kidneyToolStripMenuItem.Text = "Kidney";
            // 
            // renalCellCarcinomasToolStripMenuItem
            // 
            this.renalCellCarcinomasToolStripMenuItem.Name = "renalCellCarcinomasToolStripMenuItem";
            this.renalCellCarcinomasToolStripMenuItem.Size = new System.Drawing.Size(223, 22);
            this.renalCellCarcinomasToolStripMenuItem.Text = "Renal Cell Carcinomas";
            // 
            // transitionalCellCarcinomasToolStripMenuItem
            // 
            this.transitionalCellCarcinomasToolStripMenuItem.Name = "transitionalCellCarcinomasToolStripMenuItem";
            this.transitionalCellCarcinomasToolStripMenuItem.Size = new System.Drawing.Size(223, 22);
            this.transitionalCellCarcinomasToolStripMenuItem.Text = "Transitional Cell Carcinomas";
            // 
            // wilmsTumorsToolStripMenuItem
            // 
            this.wilmsTumorsToolStripMenuItem.Name = "wilmsTumorsToolStripMenuItem";
            this.wilmsTumorsToolStripMenuItem.Size = new System.Drawing.Size(223, 22);
            this.wilmsTumorsToolStripMenuItem.Text = "Wilms Tumors";
            // 
            // softTissueToolStripMenuItem
            // 
            this.softTissueToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fibrosarcomaToolStripMenuItem,
            this.dermatofibrosarcomaToolStripMenuItem,
            this.fibromatosisToolStripMenuItem});
            this.softTissueToolStripMenuItem.Name = "softTissueToolStripMenuItem";
            this.softTissueToolStripMenuItem.Size = new System.Drawing.Size(75, 20);
            this.softTissueToolStripMenuItem.Text = "Soft Tissue";
            // 
            // fibrosarcomaToolStripMenuItem
            // 
            this.fibrosarcomaToolStripMenuItem.Name = "fibrosarcomaToolStripMenuItem";
            this.fibrosarcomaToolStripMenuItem.Size = new System.Drawing.Size(190, 22);
            this.fibrosarcomaToolStripMenuItem.Text = "Fibrosarcoma";
            // 
            // dermatofibrosarcomaToolStripMenuItem
            // 
            this.dermatofibrosarcomaToolStripMenuItem.Name = "dermatofibrosarcomaToolStripMenuItem";
            this.dermatofibrosarcomaToolStripMenuItem.Size = new System.Drawing.Size(190, 22);
            this.dermatofibrosarcomaToolStripMenuItem.Text = "Dermatofibrosarcoma";
            // 
            // fibromatosisToolStripMenuItem
            // 
            this.fibromatosisToolStripMenuItem.Name = "fibromatosisToolStripMenuItem";
            this.fibromatosisToolStripMenuItem.Size = new System.Drawing.Size(190, 22);
            this.fibromatosisToolStripMenuItem.Text = "Fibromatosis";
            // 
            // pelivisToolStripMenuItem
            // 
            this.pelivisToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.chondrosarcomaToolStripMenuItem,
            this.osteosarcomaToolStripMenuItem,
            this.bladderCancerToolStripMenuItem});
            this.pelivisToolStripMenuItem.Name = "pelivisToolStripMenuItem";
            this.pelivisToolStripMenuItem.Size = new System.Drawing.Size(52, 20);
            this.pelivisToolStripMenuItem.Text = "Pelivis";
            // 
            // chondrosarcomaToolStripMenuItem
            // 
            this.chondrosarcomaToolStripMenuItem.Name = "chondrosarcomaToolStripMenuItem";
            this.chondrosarcomaToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
            this.chondrosarcomaToolStripMenuItem.Text = "Chondrosarcoma";
            // 
            // osteosarcomaToolStripMenuItem
            // 
            this.osteosarcomaToolStripMenuItem.Name = "osteosarcomaToolStripMenuItem";
            this.osteosarcomaToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
            this.osteosarcomaToolStripMenuItem.Text = "Osteosarcoma";
            // 
            // bladderCancerToolStripMenuItem
            // 
            this.bladderCancerToolStripMenuItem.Name = "bladderCancerToolStripMenuItem";
            this.bladderCancerToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
            this.bladderCancerToolStripMenuItem.Text = "Bladder Cancer";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutUsToolStripMenuItem,
            this.fAQToolStripMenuItem,
            this.socialsToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(124, 70);
            // 
            // aboutUsToolStripMenuItem
            // 
            this.aboutUsToolStripMenuItem.Name = "aboutUsToolStripMenuItem";
            this.aboutUsToolStripMenuItem.Size = new System.Drawing.Size(123, 22);
            this.aboutUsToolStripMenuItem.Text = "About Us";
            // 
            // fAQToolStripMenuItem
            // 
            this.fAQToolStripMenuItem.Name = "fAQToolStripMenuItem";
            this.fAQToolStripMenuItem.Size = new System.Drawing.Size(123, 22);
            this.fAQToolStripMenuItem.Text = "FAQ";
            // 
            // socialsToolStripMenuItem
            // 
            this.socialsToolStripMenuItem.Name = "socialsToolStripMenuItem";
            this.socialsToolStripMenuItem.Size = new System.Drawing.Size(123, 22);
            this.socialsToolStripMenuItem.Text = "Socials";
            // 
            // WinCT
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::AtkinsChisholmFrazier.Properties.Resources.nursing_hero1;
            this.ClientSize = new System.Drawing.Size(1052, 547);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.menuStrip2);
            this.Name = "WinCT";
            this.Text = "WinCT";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

		}

		#endregion
		private System.Windows.Forms.ProgressBar progressBar1;
		private System.Windows.Forms.OpenFileDialog openFileDialog1;
		private System.Windows.Forms.OpenFileDialog openFileDialog2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem mMCToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem puicuiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jipwcuiwaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem uipchwpuiawToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ncwapuiwToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cawuipnwuicToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hcapuiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem liverToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lungToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kidneyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem softTissueToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pelivisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gastrointestinalStromalTumorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem neuroendocrinecarcinoidTumorsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nonHodgkinsLymphomaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thymomaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hepatocellularCarcinomaHCCToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fibrolamellarHCCToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem secondaryLiverCancerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lungNodulesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nonsmallCellLungCancerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mesotheliomaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem renalCellCarcinomasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem transitionalCellCarcinomasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem wilmsTumorsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fibrosarcomaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dermatofibrosarcomaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fibromatosisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem chondrosarcomaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem osteosarcomaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bladderCancerToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem aboutUsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fAQToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem socialsToolStripMenuItem;
    }
}

