﻿using System;
/*
 Jaylon Atkins
3037
OLA 1
 */
namespace OLA1
{
    class Program
    {
        static void Main(string[] args)
        {

            /*
            Some of this is not used:
            There will need to be a variable that subtracts from total for the different tax brackets
            Will need a loop to calculate the deminishing the total
                store the deminishing tax total in a variable (double)

             if (status == 0) 
            {// Compute tax for single filers}
            else if (status == 1) 
            {// Compute tax for married filing jointly or qualifying widow(er)}
            else if (status == 2) 
            {// Compute tax for married filing separately}
            else if (status == 3) 
            {// Compute tax for head of household}else {// Display wrong status

            the program will have to use a switch statement to manuver the stauts
            from there if statements will be used based on the income

            A variable may be used when after the income is given to hold the percentage
            ex 10000 will be 10 percent for a single but 15 percent Married filing Jointly
            In total: 4 Swtich Statements
                In each statement:
                    If statement for the taxes base on each percentage
            */

            Console.WriteLine("Enter the filing status: ");
            int filingStatus = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter the taxable income: ");
            double income = double.Parse(Console.ReadLine());

            double tenPercent = .10;
            double fiftenPercent = .15;
            double twentyFivePercent = .25;
            double twentyEightPercent = .28;
            double thirtyThreePercent = .33;
            double thirtyFivePercent = .35;
            double totalTaxes = 0;


            //while (income  )
            switch (filingStatus)
            {
                case 0:
                    {
                        if (income <= 8350)
                            totalTaxes += income * tenPercent;

                        else if (income > 8351 && income < 33950)
                        {
                            totalTaxes = (8350 * tenPercent) + (income - 8350) * fiftenPercent;
                        }
                        else if (income > 33951 && income < 82250)
                        {
                            totalTaxes = (8350 * tenPercent) + (33950 - 8350) * fiftenPercent +
                                (income - 33950) *twentyFivePercent;
                        }
                        else if (income > 82251 && income < 171550)
                        {
                            totalTaxes = (8350 * tenPercent) + (33950 - 8350) * fiftenPercent +
                                (82250 - 33950) * twentyFivePercent + (income - 82250) * twentyEightPercent;
                        }
                        else if (income > 171551 && income < 372950)
                        {
                            totalTaxes = (8350 * tenPercent) + (33950 - 8350) * fiftenPercent +
                            (82250 - 33950) * twentyFivePercent + (171550 - 82250) * twentyEightPercent +
                            (income - 171550) * thirtyThreePercent;
                        }
                        else
                        {
                            totalTaxes = (8350 * tenPercent) + (33950 - 8350) * fiftenPercent +
                            (82250 - 33950) * twentyFivePercent + (171550 - 82250) * twentyEightPercent +
                            (income - 171550) * thirtyThreePercent + (income - 372950) * thirtyFivePercent;
                        }
                    }
                    break;

                case 1:
                    {
                        if (income <= 16700)
                            totalTaxes += income * tenPercent;

                        else if (income <= 67900)
                        {
                            totalTaxes = (16700 * tenPercent) + (income - 16700) * fiftenPercent;
                        }
                        else if (income <= 137050)
                        {
                            totalTaxes = (16700 * tenPercent) + (67900 - 16700) * fiftenPercent +
                                (income - 67900) * twentyFivePercent;
                        }
                        else if (income <= 208850)
                        {
                            totalTaxes = (16700 * tenPercent) + (67900 - 16700) * fiftenPercent +
                             (137050 - 67900) * twentyFivePercent + (income - 137050) * twentyEightPercent;
                        }
                        else if (income <= 372950)
                        {
                            totalTaxes = (16700 * tenPercent) + (67900 - 16700) * fiftenPercent +
                             (137050 - 67900) * twentyFivePercent + (208850 - 137050) * twentyEightPercent +
                            (income - 208850) * thirtyThreePercent;
                        }
                        else
                        {
                            totalTaxes = (16700 * tenPercent) + (67900 - 16700) * fiftenPercent +
                             (137050 - 67900) * twentyFivePercent + (208850- 137050) * twentyEightPercent +
                             (372950 - 208851) * thirtyThreePercent + (income - 372950) * thirtyFivePercent;
                        }
                    }
                    break;

                case 2:
                    {
                        if (income <= 8350)
                            totalTaxes += income * tenPercent;

                        else if (income <= 33950)
                        {
                            totalTaxes = (8350 * tenPercent) + (income - 8350) * fiftenPercent;
                        }
                        else if (income <= 68525)
                        {
                            totalTaxes = (8350 * tenPercent) + (33950 - 8350) * fiftenPercent +
                                (income - 33950) * twentyFivePercent;
                        }
                        else if (income <= 104425)
                        {
                            totalTaxes = (8350 * tenPercent) + (33950 - 8350) * fiftenPercent +
                                (68525 - 33950) * twentyFivePercent + (income - 68525) * twentyEightPercent;
                        }
                        else if (income <= 186475)
                        {
                            totalTaxes = (8350 * tenPercent) + (33950 - 8350) * fiftenPercent +
                            (68525 - 33950) * twentyFivePercent + (104426 - 68525) * twentyEightPercent +
                            (income - 104426) * thirtyThreePercent;
                        }
                        else
                        {
                            totalTaxes = (8350 * tenPercent) + (33950 - 8350) * fiftenPercent +
                           (68525 - 33950) * twentyFivePercent + (104426 - 68525) * twentyEightPercent +
                           (186475 - 104426) * thirtyThreePercent + (income - 186476) * thirtyFivePercent;
                        }
                    }
                    break;

                case 3:
                    {
                        if (income <= 11950)
                            totalTaxes += income * tenPercent;

                        else if (income <= 45500)
                        {
                            totalTaxes = (11950 * tenPercent) + (income - 11950) * fiftenPercent;
                        }
                        else if (income <= 117450)
                        {
                            totalTaxes = (11950 * tenPercent) + (45500 - 11950) * fiftenPercent +
                                (income - 45500) * twentyFivePercent;
                        }
                        else if (income <= 190200)
                        {
                            totalTaxes = (11950 * tenPercent) + (45500 - 11950) * fiftenPercent +
                                (117451 - 45500) * twentyFivePercent + (income - 117451) * twentyEightPercent;
                        }
                        else if (income <= 372950)
                        {
                            totalTaxes = (11950 * tenPercent) + (45500 - 11950) * fiftenPercent +
                                (117451 - 45500) * twentyFivePercent + (199201 - 117451) * twentyEightPercent +
                                (income - 199201) * thirtyThreePercent;
                        }
                        else
                        {
                            totalTaxes = (11950 * tenPercent) + (45500 - 11950) * fiftenPercent +
                                (117451 - 45500) * twentyFivePercent + (199201 - 117451) * twentyEightPercent +
                                (372950 - 199201) * thirtyThreePercent + (income - 372950) * thirtyFivePercent;
                        }
                    }
                    break;
            }

            Console.WriteLine("Tax is " + totalTaxes);
        }
    }
}
