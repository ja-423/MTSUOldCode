﻿/*
 Jaylon Atkins
 OLA3 3037
 Due Date: 3/13/2022
 */

using System;
namespace ConsoleApp2
{
    class Program
    {
        // Method to determine the highest value
        static void highest(string[] displayArray, int[,] passedArray)
        {
            // Initializations for iterations
            int iteration_total = 0, highestVal = 0, highest_index = 0;
            // Iterates through five rows and 10 columns
            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    // Exception for the first value to prevent out of bound errors
                    // also adds the value of the column multipled by the number of votes in a category 

                    iteration_total += passedArray[i, j] * j;
                }
                // Computes the highest value with if statement
                if (iteration_total > highestVal)
                {
                    highestVal = iteration_total;
                    highest_index = i;
                }
                // reset for next iteration
                iteration_total = 0;
            }
            Console.WriteLine("Highest points: " + displayArray[highest_index] + "(" + highestVal + ")");
            Console.WriteLine();
        }

        // Method to determine the lowest value
        static void lowest(string[] displayArray, int[,] passedArray)
        {
            // Initializations for iterations
            int iteration_total = 0, lowestVal = 99999, lowest_index = 0;
            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    // Exception for the first value to prevent out of bound errors
                    // also adds the value of the column multipled by the number of votes in a category 
                    iteration_total += passedArray[i, j] * j;
                }
                // Sets the first value as the lowests
                if (i == 0)
                    lowestVal = iteration_total;

                // Computes the lowest value with if statement
                if (iteration_total <= lowestVal)
                {
                    lowestVal = iteration_total;
                    lowest_index = i;
                }
                // reset for next iteration
                iteration_total = 0;
            }
            Console.WriteLine("Lowest points: " + displayArray[lowest_index] + "(" + lowestVal + ")");
        }

        // Displays to user but also calulates averages at the end of a row
        static void display(string[] passedArray, int[,] anotherArray)
        {
            // Initializations for iterations
            double iteration_total = 0;
            int counter = 0;
            double avg = 0;

            // Table header
            Console.Write("Topic \t\t");
            for (int i = 1; i < 11; i++)
            {
                Console.Write(i + "\t");
            }
            Console.WriteLine("Average");

            // Iterates through five rows and 10 columns and will print each value in the table
            for (int i = 0; i < 5; i++)
            {
            
                Console.Write(passedArray[i] + "\t");
                for (int j = 0; j < 10; j++)
                {
                    Console.Write(anotherArray[i, j] + " \t");

                    iteration_total += anotherArray[i, j] * (j + 1);

                    // As long as a value is greater than 0 it is counted
                    if (anotherArray[i, j] > 0)
                        counter += anotherArray[i, j];

                    // The average is calulated and is printed when the end of the row is reached
                    if (j == 9)
                    {
                        avg = iteration_total / counter;
                        Console.Write(avg);

                        // Reset for next iteration, if done outside of the if statement this would occur during every iteration
                        counter = 0;
                        iteration_total = 0;
                    }
                    // Reset for next iteration
                    avg = 0;
                    
                }

                Console.WriteLine();
            }
            Console.WriteLine();
        }


        static void Main(string[] args)
        {
            // Initialization of arrays and values within them
            string[] topicNames = new string[] { "U.S War Affairs",
                                                 "Abortion",
                                                 "Global Warming",
                                                 "Health Care",
                                                 "Education" };
            int[,] fullSurvey = new int[5, 10];

            // Initialization of values used in main from user
            bool noMoreData = false;
            int readingFromUser, userChoice;

            // While the there is data to read the user will be prompted and their choices will be logged
            while (noMoreData == false)
            {
                for (int topic = 0; topic < 5; topic++)
                {
                    Console.WriteLine("On a scale of 1 - 10, how important is " + topicNames[topic]);
                    readingFromUser = int.Parse(Console.ReadLine());

                    // If a value is given out of bounds it will hold until a valid value is given
                    while (readingFromUser < 1 || readingFromUser > 10)
                    {
                        Console.WriteLine("Your response should be between 1 and 10 please try again ");
                        readingFromUser = int.Parse(Console.ReadLine());
                    }

                    // adds one to the index in the display
                    ++fullSurvey[topic, readingFromUser - 1];
                }

                // Determines to continue or ask for more data
                Console.WriteLine("Enter more data? ");
                userChoice = int.Parse(Console.ReadLine());
                if (userChoice == 0)
                    noMoreData = true;
                else
                    noMoreData = false;
            }

            // Call statements
            display(topicNames, fullSurvey);
            highest(topicNames, fullSurvey);
            lowest(topicNames, fullSurvey);
        }
    }
}
