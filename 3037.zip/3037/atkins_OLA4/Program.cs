﻿using System;

namespace atkins_OLA4
{
    public partial class Form1 : Form
    {
        Double resultValue = 0;
        String operationPerformed = "";
        bool isOperationPerformed = false;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
                textBox1.Clear();

            Button button = (Button)sender;
            textBox1.Text = textBox1.Text + "1";
            isOperationPerformed = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
                textBox1.Clear();

            Button button = (Button)sender;
            textBox1.Text = textBox1.Text + "2";
            isOperationPerformed = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
                textBox1.Clear();

            Button button = (Button)sender;
            textBox1.Text = textBox1.Text + "3";
            isOperationPerformed = false;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
                textBox1.Clear();

            Button button = (Button)sender;
            textBox1.Text = textBox1.Text + "4";
            isOperationPerformed = false;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
                textBox1.Clear();

            Button button = (Button)sender;
            textBox1.Text = textBox1.Text + "5";
            isOperationPerformed = false;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
                textBox1.Clear();

            Button button = (Button)sender;
            textBox1.Text = textBox1.Text + "6";
            isOperationPerformed = false;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
                textBox1.Clear();

            Button button = (Button)sender;
            textBox1.Text = textBox1.Text + "7";
            isOperationPerformed = false;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
                textBox1.Clear();

            Button button = (Button)sender;
            textBox1.Text = textBox1.Text + "8";
            isOperationPerformed = false;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
                textBox1.Clear();

            Button button = (Button)sender;
            textBox1.Text = textBox1.Text + "9";
            isOperationPerformed = false;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
                textBox1.Clear();

            Button button = (Button)sender;
            textBox1.Text = textBox1.Text + "0";
            isOperationPerformed = false;
        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
                textBox1.Clear();

            Button button = (Button)sender;
            textBox1.Text = textBox1.Text + "00";
            isOperationPerformed = false;
        }

        //Addition
        private void button12_Click(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            operationPerformed = button.Text;
            resultValue = Double.Parse(textBox1.Text);
            isOperationPerformed = true;
            textBox1.Text = "";
        }

        // Minus button
        private void button13_Click(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            operationPerformed = button.Text;
            resultValue = Double.Parse(textBox1.Text);
            isOperationPerformed = true;
            textBox1.Text = "";
        }

        // Multiplication
        private void button14_Click(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            operationPerformed = button.Text;
            resultValue = Double.Parse(textBox1.Text);
            isOperationPerformed = true;
            textBox1.Text = "";
        }

        // Division
        private void button15_Click(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            operationPerformed = button.Text;
            resultValue = Double.Parse(textBox1.Text);
            isOperationPerformed = true;
            textBox1.Text = "";
        }

        // Equals
        private void button16_Click(object sender, EventArgs e)
        {
            switch (operationPerformed)
            {
                case "+":
                    textBox1.Text = (resultValue + Double.Parse(textBox1.Text)).ToString();
                    break;
                case "-":
                    textBox1.Text = (resultValue - Double.Parse(textBox1.Text)).ToString();
                    break;
                case "*":
                    textBox1.Text = (resultValue * Double.Parse(textBox1.Text)).ToString();
                    break;
                case "/":
                    textBox1.Text = (resultValue / Double.Parse(textBox1.Text)).ToString();
                    break;

                default:
                    break;
            }
        }

        private void button18_Click(object sender, EventArgs e)
        {
            textBox1.Text = "0";
        }

        private void button19_Click(object sender, EventArgs e)
        {
            textBox1.Text = "0";
            resultValue = 0;
        }

        // point
        private void button17_Click(object sender, EventArgs e)
        {
            if ((textBox1.Text == "0") || (isOperationPerformed))
                textBox1.Clear();


            isOperationPerformed = false;
            Button button = (Button)sender;
            if (button.Text == ".")
            {
                if (textBox1.Text.Contains("."))
                    textBox1.Text = textBox1.Text + button.Text;
            }
            else
                textBox1.Text = textBox1.Text + button.Text;
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.NumPad1:
                    button1.PerformClick();
                    break;
                case Keys.D1:
                    button1.PerformClick();
                    break;

                case Keys.NumPad2:
                    button2.PerformClick();
                    break;
                case Keys.D2:
                    button2.PerformClick();
                    break;

                case Keys.NumPad3:
                    button3.PerformClick();
                    break;
                case Keys.D3:
                    button3.PerformClick();
                    break;

                case Keys.NumPad4:
                    button4.PerformClick();
                    break;
                case Keys.D4:
                    button4.PerformClick();
                    break;

                case Keys.NumPad5:
                    button5.PerformClick();
                    break;
                case Keys.D5:
                    button5.PerformClick();
                    break;

                case Keys.NumPad6:
                    button6.PerformClick();
                    break;
                case Keys.D6:
                    button6.PerformClick();
                    break;

                case Keys.NumPad7:
                    button7.PerformClick();
                    break;
                case Keys.D7:
                    button7.PerformClick();
                    break;

                case Keys.NumPad8:
                    button8.PerformClick();
                    break;
                case Keys.D8:
                    button8.PerformClick();
                    break;

                case Keys.NumPad9:
                    button9.PerformClick();
                    break;
                case Keys.D9:
                    button9.PerformClick();
                    break;

                case Keys.NumPad0:
                    button10.PerformClick();
                    break;
                case Keys.D0:
                    button10.PerformClick();
                    break;

                case Keys.Add:
                    button12.PerformClick();
                    break;

                case Keys.Subtract:
                    button13.PerformClick();
                    break;

                case Keys.Multiply:
                    button14.PerformClick();
                    break;

                case Keys.Divide:
                    button15.PerformClick();
                    break;

                default:
                    break;
            }
        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Enter:
                    button16.PerformClick();
                    break;
                default:
                    break;
            }
        }

        private void button20_Click(object sender, EventArgs e)
        {
            System.Environment.Exit(0);
        }
    }
}
