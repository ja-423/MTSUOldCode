This project simulated the shuffle of a card deck with the standard 52 cards including face cards.
This was completed in Spring of 2021.
