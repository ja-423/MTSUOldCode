/*
Jaylon Atkins
CSCI 3110-001
Project #7
Due: 04/28/21
*/
#include "card.h"
#include <string.h>
#include "priorityqueue.h"
using namespace std;

/* Default constructor that taks an integer and the tape of suit to be eastablished
   number cards will stay the same however the ace and face card are assigned new
   values.
*/

Card::Card(int valueOfFace, suit nameOfsuit)
{
	cardFace = valueOfFace;
	cardSuit = nameOfsuit;
}

// Overloaded operator for that takes an ostream output and a constant refrence value of the Card class
// Two strings are created and are assigned based on the card face values with updated values for output.

ostream& operator << (ostream& output, const Card& card)
{
	string realSuit, realFace;

	if (card.cardFace == 1)
		realFace = "A";

	else if (card.cardFace == 2)
		realFace = "2";

	else if (card.cardFace == 3)
		realFace = "3";

	else if (card.cardFace == 4)
		realFace = "4";

	else if (card.cardFace == 5)
		realFace = "5";

	else if (card.cardFace == 6)
		realFace = "6";

	else if (card.cardFace == 7)
		realFace = "7";

	else if (card.cardFace == 8)
		realFace = "8";

	else if (card.cardFace == 9)
		realFace = "9";

	else if (card.cardFace == 10)
		realFace = "10";

	else if (card.cardFace == 11)
		realFace = "J";

	else if (card.cardFace == 12)
		realFace = "Q";

	else if (card.cardFace == 13)
		realFace = "K";

	if (card.cardSuit == hearts)
		realSuit = "H";
	
	else if (card.cardSuit == diamonds)
		realSuit = "D";

	else if (card.cardSuit == clubs)
		realSuit = "C";

	else if (card.cardSuit == spades)
		realSuit = "S";

	output << realFace << realSuit << "[" << card.cardFace << "]";
	return output; 
}

// These operators compare a passed in card class to a current card class these are booleans values

bool Card::operator < (const Card& card) const
{
	if (this->cardFace < card.cardFace)
		return true;
	else
		return false;
}

bool Card::operator > (const Card& card) const
{
	if (this->cardFace > card.cardFace)
		return true;
	else
		false;
}

bool Card::operator >= (const Card& card) const
{
	if (this->cardFace >= card.cardFace)
		return true;
	else
		false;
}

bool Card::operator <= (const Card& card) const
{
	if (this->cardFace <= card.cardFace)
		return true;
	else
		false;
}

bool Card::operator == (const Card& card) const
{
	if (this->cardFace == card.cardFace)
		return true;
	else
		false;
}