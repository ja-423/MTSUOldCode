/*
Jaylon Atkins
CSCI 3110-001
Project #7
Due: 04/28/21
*/
#ifndef CARD_H
#define CARD_H

#include <iostream>
using std::ostream;

// Enumerated type that represents the card suits
enum suit {diamonds, clubs, hearts, spades};

class Card
{
public:
    //default constructor - required
	Card() {};

    //constructor that takes a card's face value (an integer) and its suit
	// card face example: Ace=0, 2=1, 3=2, ... Q=11, K=12
	Card (int face, suit st);

    // overload the << operator to display the card
    friend ostream& operator << (ostream& os, const Card& cd);

    // compare and return true if *this has a lesser point value than cd, false otherwise
	bool operator < (const Card& cd) const;

    // compare and return true if *this has a larger point value than cd, false otherwise
	bool operator > (const Card& cd) const;

    // compare and return true if *this has the same point value as cd, false otherwise
	bool operator== (const Card& cd) const;
	
	bool operator <= (const Card& cd) const;

	bool operator >= (const Card& cd) const;

private:
	suit	cardSuit;		// card's suit
	int     cardFace;		// card's face value
};
#endif


