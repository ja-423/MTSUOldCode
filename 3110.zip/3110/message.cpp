Answer:
proj7.cpp


#include <iostream>
#include <queue>
#include <cstdlib>
#include <vector>
#include <string>
#include <algorithm>
#include "card.h"
#include "priorityqueue.h"
using std::string;
using std::cout;
using std::endl;

int main()
{

    // instantiate  max priority queue
    // pq <card, comp> mymaxqueue
    PriorityQueue <Card, MaxHeap<Card> > maxQueue;

    //min priority queue
    PriorityQueue <Card, MinHeap<Card>> minQueue;

    // instantiate an array of 13 cards in the spades suit
    //Card cards(13, spades);

    std::vector<Card> cards;
    for (int i = 1; i <= 13; i++)
        cards.push_back(Card(i, spades));

    //for (int i = 0; i < 13; i++)
        //cout << cards[i] << " ";
    //cout << endl;

    // shuffle the cards in array using std::random_shuffle()
    std::random_shuffle(cards.begin(), cards.end());

    //for (int i = 0; i < 13; i++)
        //cout << cards[i] << " ";
    //cout << endl;


    //**** MaxQueue ****//

    // enqueue the first seven cards in the max priority queue and display the heap's contents after each enqueue
    for (int i = 0; i < 7; i++)
    {
        cout << "Enqueuing " << cards[i] << "\n" << "\t";
        maxQueue.enqueue(cards[i], MaxHeap<Card>{});
        maxQueue.print();
        cout << endl;
    }
    cout << endl;

    // dequeue each card individually from the max priority queue until it's empty - display the heap's contents after each dequeue


    for (int i = 0; i < 7; i++)
    {
        maxQueue.dequeue(MaxHeap<Card>{});
        maxQueue.print();
        cout << endl;
    }
    cout << "Max Heap is empty.\n";
    cout << endl;

    //**** MinQueue ****//

    // enqueue the remaining six cards in the min priority queue and display the heap's contents after each enqueue

    for (int j= 7; j < 13; j++)
    {
        cout << "Enqueuing "<< cards[j] << "\n" << "\t";
        minQueue.enqueue(cards[j], MinHeap<Card>{});
        minQueue.print();
        cout << endl;
    }
    cout << endl;

    // dequeue each card individually from the min priority queue until it's empty - display the heap's contents after each dequeue
    for (int j = 7; j < 13; j++)
    {
        minQueue.dequeue(MinHeap<Card>{});
        minQueue.print();
        cout << endl;
    }
    cout << "Min Heap is empty.\n";
    cout << endl;

    system("pause");
    return 0;
    
}


card.cpp


#include <iostream>
#include <queue>
#include <cassert>
#include <string>
#include "card.h"
#include "priorityqueue.h"
using std::string;
using std::cout;
using std::endl;


//constructor that takes a card's face (represented an integer) and suit
// card face example: Ace=0, 2=1, 3=2, ... Q=11, K=12 or some other ordering

Card::Card()
{}

Card::Card(int face, suit st)
{
    cardSuit = st;
    cardFace = face;

}

// overload the << operator to display the card
std::ostream& operator << (ostream& os, const Card& cd)
{
    char suit = cd.cardSuit;    //holds the card's suit

                                // print suit symbol
    if (suit == hearts)
        suit = 'H';
    else if (suit == diamonds)
        suit = 'D';
    else if (suit == clubs)
        suit = 'C';
    else if (suit == spades)
        suit = 'S';

    // prints the cardFace and cardSuit
    if (cd.cardFace == 1)
        os << "A" << suit << "[" << cd.cardFace << "]" << " ";
    else if (cd.cardFace > 1 && cd.cardFace <= 10)
        os << cd.cardFace << suit << "[" << cd.cardFace << "]" << " ";
    else if (cd.cardFace == 11)
        os << "J" << suit << "[" << cd.cardFace << "]" << " ";
    else if (cd.cardFace == 12)
        os << "Q" << suit << "[" << cd.cardFace << "]" << " ";
    else if (cd.cardFace == 13)
        os << "K" << suit << "[" << cd.cardFace << "]" << " ";
    return os;
}

// compare and return true if *this has a lesser point value than cd, false otherwise
bool Card:: operator <= (const Card& cd) const
{
    if (cardFace <= cd.cardFace)
        return true;
    else
        return false;
}

// compare and return true if *this has a larger point value than cd, false otherwise
bool Card:: operator >= (const Card& cd) const
{
    if (cardFace >= cd.cardFace)
        return true;
    else
        return false;
}

// compare and return true if *this has the same point value as cd, false otherwise
bool Card::operator== (const Card& cd) const
{
    if (cardFace == cd.cardFace)
        return true;
    else
        return false;
}


card.h


#pragma once

#include <iostream>
#include <queue>
#include <string>
using std::string;
using std::cout;
using std::endl;
using std::ostream;


#ifndef CARD_H
#define CARD_H

 

// Enum type that represents the card suits
enum suit { clubs, hearts, spades, diamonds };

class Card
{
public:
    //default constructor - required
    Card();

    //constructor that takes a card's face (represented an integer) and suit
    // card face example: Ace=0, 2=1, 3=2, ... Q=11, K=12 or some other ordering
    Card(int face, suit st);

    // overload the << operator to display the card
    friend ostream& operator << (ostream& os, const Card& cd);

    // compare and return true if *this has a lesser point value than cd, false otherwise
    bool operator <= (const Card& cd) const;

    // compare and return true if *this has a larger point value than cd, false otherwise
    bool operator >= (const Card& cd) const;

    // compare and return true if *this has the same point value as cd, false otherwise
    bool operator== (const Card& cd) const;

 

private:
    suit    cardSuit;        // card's suit
    int     cardFace;        // card's face
                            // card's point value (derived from face)
};
#endif

priorityqueue.h

#pragma once


#include <iostream>
#include <queue>
#include <vector>
#include <string>
#include "card.h"
using std::string;
using std::cout;
using std::endl;
using std::vector;

#ifndef PRIORITYQUEUE_H
#define PRIORITYQUEUE_H

// This class represents a priority queue implemented as a binary heap. It has
// two type parameters : 1) The type of the element stored in the heap 2) A comparator class.
template <typename EleStoredType, typename Comparator>

// stores items and restricts accesses to the
// highest priority item
class PriorityQueue
{
public:
    // resize the vector representing the heap to hold 50 items
    PriorityQueue()
    {
        heapArr.resize(50);
    }

    // returns the highest priority item in the heap. does not change the heap
    int top(EleStoredType index)
    {
        // return the root
        int parent= (index - 1) / 2;

        return heapArr[parent];
    }

    // has a comparator parameter. removes the highest priority item in the heap
    void dequeue(Comparator cmp)
    {
        cout << "Dequeuing " << heapArr[0] << "\n" << "\t";
        
        //replace parent with last child in heap
        // removes the last element in vector
        heapArr[0] = heapArr[size - 1];

        //heapArr[size - 1] = heapArr[size];

        // reduces the container size by one
        size--;

        //heap down
        heapDown(0, cmp);

    }

    // enqueues the item and places it in the heap in priority order
    void enqueue(EleStoredType item, Comparator cmp)
    {
        // insert item at size
        // put the item at the end of the heap
            heapArr[size] = item;
            size++;

            // heap up
            heapUp(size - 1, cmp);
    }

    // displays the items in the heap, from index 0 through index size-1
    void print()
    {
        if (size == -1)
            cout << "is empty";
        else
            for (int i = 0; i < size; i++)
                cout << heapArr[i] << ' ';
    }

private:

    vector<EleStoredType> heapArr;
    int size = 0;

    // percolates the item up based on its priority
    void heapUp(int index, Comparator cmp)
    {
        // parent
        int parent = (index - 1) / 2;
    
        // base case
        if (index == 0 || cmp.HighPriority(heapArr[parent], heapArr[index]))
            return;
        
        // while the element is not the parent and the index is greater than or equal to the parent's element
        // swap the element with its parent
        // call the  recursive function
        if (cmp.HighPriority(heapArr[index], heapArr[parent]))
        {
            EleStoredType temp = heapArr[parent];
            heapArr[parent] = heapArr[index];
            heapArr[index] = temp;

            //cout << "Heap Up HERE \n";
            heapUp(parent, cmp);
        }

    }

    // percolates the item down based on its priority
    void heapDown(int index, Comparator cmp)
    {
        int left_child = (index * 2) + 1;
        int right_child = (index * 2) + 2;
        

        // base case
        if (left_child > size)
            return;

        int largest = index;
        // check if the left child is the largest
        if (cmp.HighPriority(heapArr[left_child], heapArr[index]))
            largest = left_child;

        // check if the right child is the largest
        if (right_child < size && (cmp.HighPriority(heapArr[right_child], heapArr[largest])))
            largest = right_child;

        // swap
        if (largest != index)
        {
            EleStoredType temp = heapArr[index];
            heapArr[index] = heapArr[largest];
            heapArr[largest] = temp;

            //cout << "Heap Down HERE \n";
            heapDown(largest, cmp);
        }
    }

};


// first templated class comparator that take a type parameter bool
template <typename EleStoredType>

class MinHeap
{
public:
    // returns if the item is less than or equal (<=) to the other one
    bool HighPriority(const EleStoredType &lhs, const EleStoredType &rhs) const
    {
        return (lhs <= rhs);
    }
};

// Second templated class comparator that take a type parameter bool
template <typename EleStoredType>

class MaxHeap
{
public:
    // returns if the item is less than or equal (<=) to the other one
    bool HighPriority(const EleStoredType &lhs, const EleStoredType &rhs) const
    {
        //cout << "in cmp " << lhs << " " << rhs << "\n";
        return (lhs >= rhs);
    }
};


#endif