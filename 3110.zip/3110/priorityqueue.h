/*
Jaylon Atkins
CSCI 3110-001
Project #7
Due: 04/28/21
*/

// Incldue statements for processing data
#include <iostream>
#include <string>
#include <queue>
#include <vector>
#include "card.h"
using namespace std;

#ifndef PRIORITYQUEUE_H
#define PRIORITYQUEUE_H

// Creates templates of the type of data to be processed and its comparator
template <typename typeOfData, typename Comparator>

// Class of PriorityQueue that holds enacts operations of data types

class PriorityQueue
{
private:
    // Intializes the object arrayHeap that holds the typeOfdata object
    // and the size of the heap
    vector<typeOfData> arrayHeap;
    Comparator comparing;
    int sizeOfHeap = 0;

    // Determines the hierarchy of an item first finds of the poistion of the parent
    // is zero that passed in. If not there is a temporary "moving" object that is
    // determing to swap the moving element with the parent

    void heapUp(int position)
    {
        int parentOfHeap = (position - 1) / 2;
        if (position != 0 && comparing.comparingData(arrayHeap[position], arrayHeap[parentOfHeap]) == true)
        {
            swap(arrayHeap[position], arrayHeap[parentOfHeap]);
            heapUp(parentOfHeap);
        }
        /*
        typeOfData moving = arrayHeap[parentOfHeap];
        arrayHeap[parentOfHeap] = arrayHeap[position];
        arrayHeap[position] = moving;
        heapUp(parentOfHeap);*/
    }

    // Determines the hierarchy of an item but downwards and checks the heap based on its
    // left and right children. The function will swap items if the larger item is greater
    // than the one in the current position

    void heapDown(int position)
    {
        int leftChild = (position * 2) + 1;
        int rightChild = (position * 2) + 2;
        int maxmium = position;

        if (leftChild > sizeOfHeap)
            return;

        if (rightChild < sizeOfHeap)
            maxmium = rightChild;
        
        if (maxmium != position)
        {
            typeOfData moving = arrayHeap[position];
            arrayHeap[position] = arrayHeap[maxmium];
            arrayHeap[maxmium] = moving;
            heapDown(maxmium);
        }
    }
public:
// Constructor that fixes the heap at 50 items.
    PriorityQueue()
    {
        arrayHeap.resize(50);
        sizeOfHeap = 0;
    }

    // Removes the highest element in the heap and moves down the heap
    // by shifting the index down one element and cutting the size of the heap by 1
    void dequeue()
    {
        //cout << "Dequeued " << arrayHeap[0] << " ";

        swap(arrayHeap[sizeOfHeap - 1], arrayHeap[0]);
        //arrayHeap[0] = arrayHeap[sizeOfHeap - 1];
        sizeOfHeap --;
        heapDown(0);
    }

// Places an item in the heap based on its hierarchy the heap will increase as heapUp
// is called to move positions.
    void enqueue(typeOfData passedItem)
    {
        arrayHeap[sizeOfHeap] = passedItem;
        sizeOfHeap++;
        heapUp(sizeOfHeap - 1);
    }
// Will signal to user if the heap is empty
    bool empty()
    {
        if (sizeOfHeap == -1)
        {
            cout << "Heap Empty";
            return true;
        }
        else
            return false;
    }
    // Prints the items of the heap
    void print()
    {
        for (int i = 0; i < sizeOfHeap; i++)
            cout << arrayHeap[i] << " ";
    } 
};


// These template class determine the greater than or less than of the data that are taken 
// as parameters. These are boolean functions to determine the hiarachy of the heap
    template <typename typeOfData>

    class minimumHeap
    {
        public:
        bool comparingData(const typeOfData &left, const typeOfData &right) const
        {
            return (left <= right);
        }
    };

    template <typename typeOfData>

    class maximumHeap
    {
    public:
        bool comparingData(const typeOfData &left, const typeOfData &right) const
        {
            return (left >= right);
        }
    };

#endif
