/*Jaylon Atkins
CSCI 3110-001 (your section #)
Project #05
Due: 03/25/21
*/

// Include statements for interpreting data
#include <fstream>
#include <iostream>
#include <string>
#include "treasuremap.h"
using namespace std;

/* 
Main creates an ifstream object and TreasureMap object that takes the 
the ifstream object as a parameter. A bool object is also created
and the intial map of the TreasureMap is printed as well as the intialization of
the TreasureMap object at 1,1.
*/
int main()
{
ifstream fancyfile;
TreasureMap newMap(fancyfile);
bool isFound;

newMap.PrintMap();
newMap.FindTreasure(1,1,isFound);

}