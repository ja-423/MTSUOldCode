/*
Jaylon Atkins
CSCI 3110-001 (your section #)
Project #6
Due: 04/13/21
*/

// Include statements and declaration for interpretation of data
#include <fstream>
#include <iostream>
#include <string>
#include <string.h>
#include <algorithm>
#include "wordtree.h"
using namespace std;

int main()
{
// Creates two streams for two files and opens them
ifstream fancyfile, fancyfile2;
fancyfile.open("input.txt");
fancyfile2.open("queries.txt");

// Intalizes characters, strings, integers, and WordTree object
char findType;
string newWord, searchWord;
int occurs;
WordTree newSprout;

// Before the file ends read in a word transform it to 
// lowercase and add it to the WordTree object
while(!fancyfile.eof())
{
    fancyfile >> newWord;
    transform(newWord.begin(), newWord.end(), newWord.begin(),
    [](unsigned char c){ return tolower(c); });
    newSprout.addWord(newWord);

}
cout << "Word tree built and loaded" << endl << endl;

/*
For every character value read determine if it’s C or F and receive the proper parameter
Display message to the user and use the proper function of the Word Tree Object 
*/

while(fancyfile2 >> findType)
{
    if (findType == 'C')
    {
        fancyfile2 >> occurs;
        cout << "Finding all words with " << occurs << " or more occurrence:" << endl;
        newSprout.getCounts(occurs);
    }
    else if (findType == 'F')
    {
        fancyfile2 >> searchWord;
        cout << "Searching for occurrences of the word '" << searchWord << "'" << endl;
        newSprout.findWord(searchWord);
    }
}
return 0;
}