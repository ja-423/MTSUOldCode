/*
Jaylon Atkins
CSCI 3110-001
Project #7
Due: 04/28/21
*/

// Incldue statements for processing data
#include <iostream>
#include <fstream>
#include <algorithm>
#include <queue>
#include "card.h"
#include "priorityqueue.h"
using namespace std;

int main()
{
    // Intalizes PriorityQueue object types for the minimum 
    // and maxium heaps that each take on the Card class and the Comparators class
    // also intializes the two arrays of the Card objects 
    // as well as the file and seed to read
    PriorityQueue <Card, maximumHeap<Card>> maxQueue;
    PriorityQueue <Card, minimumHeap<Card>> minQueue;
    Card cards[13];
    Card cards2[13];
    int seed;
    ifstream fancyfile;

// Opens the file, reads and sets the seed

    fancyfile.open("pqseed.txt");
    fancyfile >> seed;
    srand(seed);
    
// The for loops assigns the arrays to their proper suits and shuffles each of them
    for(int i = 0; i < 13; i++)
    {
        cards[i] = Card(i, suit(3));
        cards2[i] = Card(i, suit(2));
    }
    std::random_shuffle(std::begin(cards), std::end(cards));
    std::random_shuffle(std::begin(cards2), std::end(cards2));

// Enqueues the first array
    for (int i = 0; i < 13; i++)
    {
        cout << "Enqueued " << cards[i] << " ";
        maxQueue.enqueue(cards[i]);
        maxQueue.print();
        cout << endl;
    }
    cout << endl;

// Dequeues the first array
    for (int i = 0; i < 13; i++)
    {
        cout << "Dequeued " << cards[i] << " ";
        maxQueue.dequeue();
        maxQueue.print();
        cout << endl;
    }
    cout << "Max Heap Empty" << endl << endl;

// Enqueues the second array    
    for (int i = 0; i < 13; i++)
    {
        cout << "Enqueued " << cards2[i] << " ";
        minQueue.enqueue(cards2[i]);
        minQueue.print();
        cout << endl;
    }
    cout << endl;

// Dequeues the second array

    for (int i = 0; i < 13; i++)
    {
        //cout << "Dequeued " << cards2[i] << " ";
        minQueue.dequeue();
        minQueue.print();
        cout << endl;
    }
    cout << "Min Heap Empty" << endl;
    
    return 0;
}