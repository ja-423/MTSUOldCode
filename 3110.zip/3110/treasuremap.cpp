/*Jaylon Atkins
CSCI 3110-001 (your section #)
Project #05
Due: 03/30/21
*/

// Include statements for interpreting data
#include <iostream>
#include <fstream>
#include <string>
#include "treasuremap.h"
using namespace std;

/* 
Default constructor that take an ifstream parameter
initalizes a character value, opens the file and reads from it
this for loop creates the map by assigning each read character and to tmap
*/
TreasureMap::TreasureMap(std::ifstream& fancyfile)
    {
        char inChar;
        fancyfile.open("treasuremap.txt");
        fancyfile >> xplor >> maxRows >> maxCols;
        for (int i = 1; i < maxRows + 1; i++)
        {
            for (int j = 1; j < maxCols + 1; j++)
            {
                fancyfile >> inChar;
                tmap[i][j] = inChar; 
            }
        }
    }

// this function prints each character of tmap
void TreasureMap::PrintMap()
    {
        cout << "Current map:" << endl;
        for(int i = 1; i < maxRows + 1; i++)
        {
            for (int j = 1; j < maxCols + 1; j++)
                cout << tmap[i][j] << " ";
            
            cout << endl;
        }

    }   

/* 
This function is recursive and takes two integers 
and a boolean reference as parameters. This function creates
an integer pair that is assigned to the returned value from the
getMove function. When this function finds the Treasure it will print
it out the the user. This function will travel land cells and change them to 
"*" and will travel over itself if it goes out of bounds.
*/
void TreasureMap::FindTreasure(int rowNum, int colNum, bool& xMarks)
    {
        std::pair<int,int> finding;
        
        if (rowNum == 1 && colNum == 1)
        {
            cout << "Start postition: 1,1" << endl;
        }    

        if (tmap[rowNum][colNum] == 'T')
            {
                xMarks = true;
                cout << "Searching " << rowNum << "," 
                << colNum << endl << "Treasure Found!" << endl;
            }
        else if (tmap[rowNum][colNum] == 'L')
        {
            tmap[rowNum][colNum] = '*';
            cout << "Searching " << rowNum << "," << colNum << endl;
            PrintMap();

            for (int i = 0; i < 4; i++)
            {    
            finding = getMove(xplor[i]);
        
            if (finding.first == -1 && finding.second == -1)
                FindTreasure(rowNum - 1, colNum - 1, xMarks);
            
            if (finding.first == -1 && finding.second  == 1)
                FindTreasure(rowNum - 1, colNum + 1, xMarks);
                
            if (finding.first == 1 && finding.second == 1)
                FindTreasure(rowNum + 1, colNum + 1 , xMarks);
                
            if (finding.first == 1 && finding.second == -1)
                FindTreasure(rowNum + 1, colNum - 1 , xMarks);
            }
        }
        else if (tmap[rowNum][colNum] != 'T' && tmap[rowNum][colNum] == '*')
        { 
        cout << "No treasure!" << endl;
        }
    }
    
/* 
This function returns an pair of integers and takes a character as a string.
The function also creates a pair and assigns the proper alteration based on which
character value is being read. This value is then returned as said character pair.
*/
std::pair<int,int> TreasureMap::getMove(char split)
    {
        std::pair<int,int> freshPair;
        if (split == '1')
            freshPair = std::make_pair(-1, -1);

        else if (split == '2')
            freshPair = std::make_pair(-1, 1);

        else if (split == '3')
            freshPair = std::make_pair(1, 1);

        else
            freshPair = std::make_pair(1, -1);
        
        return freshPair;
    
    }