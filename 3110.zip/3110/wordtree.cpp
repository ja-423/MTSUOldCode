/*
Jaylon Atkins
CSCI 3110-001 (your section #)
Project #6
Due: 04/13/21
*/

// Include statements and declaration for interpretation of data
#include <iostream>
#include <string>
#include "wordtree.h"
using namespace std;

//Constructor that initializes the root node
WordTree::WordTree()
{
    root = NULL;
}

/*
Addword function which creates new node if the passed in word is
not found The addword will compare to see where to place the node
Else the tree will increment if the word count if it’s present
*/
void WordTree::addWord(TreeNode *& newNode, string newString)
{
    if (newNode == NULL)
    {
        newNode = new TreeNode;
        newNode->value = newString;
        newNode->left = NULL;
        newNode->right = NULL;
        newNode->count ++;
    }

    else if (newString < newNode->value)
        addWord(newNode->left, newString);
    

    else if (newString > newNode->value)
        addWord(newNode->right, newString);
    
    else
        newNode->count++;
}

// Helper function of addword that passes the root and string
void WordTree::addWord(string stringer)
{
    addWord(root, stringer);
}

/*
FindWord looks for a passed in string and creates a newnode to search 
the tree InOrder The string is compared to the node first on the left 
than the right if the word is found the the info is giving to the user 
else the function returns a no message to the user.
*/
void WordTree::findWord(string anotherstring)
{
    TreeNode *findingNode = new TreeNode;
    findingNode = root;
    while(findingNode != NULL)
    {
        if (anotherstring < findingNode->value)
        {
            findingNode = findingNode->left;
        }

        else if (anotherstring > findingNode->value)
        {
            findingNode = findingNode->right;
        }
        else if (anotherstring == findingNode->value)
        {
            cout << "the word '" << anotherstring << "' occurs " 
            << findingNode->count << " time(s) in the text." << endl << endl;
            return;
        }
    }
    cout << "the word '" << anotherstring << "' was not found in the text" << endl;
}

/*
getCounts displays to the user the number of words that meet a passed in integer 
threshold of how many times a word occurs in the tree It compares the left node 
and displays it if it meets the requirements else is moves to the right node 
and does this throughout the tree. 
If the requirements are not met nothing is printed
*/
void WordTree::getCounts(TreeNode * newNode, int thres, int& quota) const
{
    if (newNode == NULL)
        return;

    getCounts(newNode->left, thres, quota);
    if (newNode->count >= thres)
    {
        cout << newNode->value << "(" << newNode->count << ")" << endl;
        quota++;
    }
    getCounts(newNode->right, thres, quota);
}

// Helper of get counts that creates the number nodes 
// that met the threshold and displays info to user
void WordTree::getCounts(int thres)
{
    int newvalue = 0;
    getCounts(root, thres, newvalue);
    cout << newvalue << " nodes had words with " << thres 
    << " or more occurrences(s)." << endl << endl;
}

// True function that deletes a passed node
void WordTree::deleteSubTree(TreeNode * passedNode)
{
    delete(passedNode);
}

// Deconstructor that release data allocated in the program from  deleteSubTree
WordTree::~WordTree()
{
    deleteSubTree(root);
}