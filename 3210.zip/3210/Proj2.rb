# Jaylon Atkins, 3210

# Creates student class with private variables and uses getters to access private members
# the initialize methods assigns values to the students
class Student
	private
	attr_accessor :studentID, :student_cla, :student_ola, :student_quiz,
			  :student_exam, :student_final, :student_total, :student_letter

	public
	def initialize(id, cla, ola, quiz, exam, final)
		@studentID = id
		@student_cla = cla.to_i
		@student_ola = ola.to_i
		@student_quiz = quiz.to_i
		@student_exam = exam.to_i
		@student_final = final.to_i
		@student_total = cla.to_i + ola.to_i + quiz.to_i + exam.to_i + final.to_i
	end

	def studentID
		@studentID
	end
	
	def student_cla
		@student_cla
	end

	def student_ola
		@student_ola
	end

	def student_quiz
		@student_quiz
	end
	
	def student_exam
		@student_exam
	end

	def student_final
		@student_final
	end

	def student_total
		@student_total
	end

	def student_letter
		@student_letter
	end

# Creates the letter grade through instance variables for each Student object
	def makeLetter(sum)
		if (sum >= 90)
			@student_letter = "A"
		elsif (sum >= 87 && sum < 90)
			@student_letter = "B+"
		elsif (sum >= 83 && sum < 87)
			@student_letter = "B"
		elsif (sum >= 80 && sum < 83)
			@student_letter = "B-"
		elsif (sum >= 77 && sum < 80)
			@student_letter = "C+"
		elsif (sum >= 73 && sum < 77)
			@student_letter = "C"
		elsif (sum >= 70 && sum < 73)
			@student_letter = "C-"
		elsif (sum >= 67 && sum < 70)
			@student_letter = "D+"
		elsif (sum >= 63 && sum < 67)
			@student_letter = "D"
		elsif (sum >= 60 && sum < 63)
			@student_letter = "D-"
		else
			@student_letter = "F"
		end
	end

end

# initilizes averages and max values that will be calculated from the roaster
def initialization()
	@hash_map = Hash.new
	@counter = 0.0
	@ola_avg = 0 
	@cla_avg = 0 
	@quiz_avg = 0 
	@exam_avg = 0 
	@final_avg = 0
	@cla_max = 0 
	@ola_max = 0 
	@quiz_max = 0 
	@exam_max = 0 
	@final_max = 0
end

# Calculates the points found from each student which calls the function to find the letter grade in the student class
def totalPointsFound()
	@hash_map.each do |key, value|
		if(@hash_map[key].studentID != "C#")
			sum = (@hash_map[key].student_cla.to_i  + 
			      @hash_map[key].student_ola.to_i  + 
			      @hash_map[key].student_quiz.to_i + 
				  @hash_map[key].student_exam.to_i + 
				  @hash_map[key].student_final.to_i)
				
				@hash_map[key].makeLetter(sum)
			end
	end
end

# Reads the line of a given file and assigns the approiate read value
def storingObjects(givenfile)
		file = File.open(givenfile)
		
		file.each_line do |line|
			key, file_cla, file_ola, file_quiz, file_exam, file_final = line.chomp.split(" ", 6)
			new_stud = Student.new(key, file_cla, file_ola, file_quiz, file_exam, file_final)
			@hash_map[key] = new_stud
		end
end

# When given a C number it will display the student and their scores
def userQuery()
	for i in 1..2 do
		puts ("Enter a C#: ")
		number = gets.chomp()
		display = "%s %s %s %s %s %s %s" %[@hash_map[number].studentID.to_s, 
									@hash_map[number].student_cla.to_s,
									@hash_map[number].student_ola.to_s,
									@hash_map[number].student_quiz.to_s,
									@hash_map[number].student_exam.to_s,		 
                  					@hash_map[number].student_final.to_s,
									@hash_map[number].student_letter.to_s]
		puts display
	end
# displays the roaster of students 	
	@hash_map.each do |key, value|
		if (@hash_map[key].studentID != "C#")
			display = "%-15s %-5s %-5s %-5s %-5s %-5s %-5s" %[@hash_map[key].studentID.to_s, 
													  @hash_map[key].student_cla.to_s,
													  @hash_map[key].student_ola.to_s,
													  @hash_map[key].student_quiz.to_s,
													  @hash_map[key].student_exam.to_s,
													  @hash_map[key].student_final.to_s,
													  @hash_map[key].student_letter.to_s]
		puts display
		else	
			display = "%-15s %-5s %-5s %-5s %-5s %-5s %-5s " %[@hash_map[key].studentID.to_s, 					  
													  @hash_map[key].student_cla.to_s,
													  @hash_map[key].student_ola.to_s,
													  @hash_map[key].student_quiz.to_s,
													  @hash_map[key].student_exam.to_s,
													  @hash_map[key].student_final.to_s,
													  @hash_map[key].student_letter.to_s]
		puts display
		end
	end
end
	
# Caluates the maximum and averages of the roaster of the class
def maxAndAvg()
	@hash_map.each do |key, value|
		if(@hash_map[key].studentID != "C#")
			@cla_avg += @hash_map[key].student_cla.to_i
			@ola_avg += @hash_map[key].student_ola.to_i
			@quiz_avg += @hash_map[key].student_quiz.to_i
			@exam_avg += @hash_map[key].student_exam.to_i
			@final_avg += @hash_map[key].student_final.to_i
			@counter += 1
		
			if (@hash_map[key].student_cla.to_i > @cla_max)
				@cla_max  = @hash_map[key].student_cla.to_i
			end
			
			if (@hash_map[key].student_ola.to_i > @ola_max )
				@ola_max  = @hash_map[key].student_ola.to_i
			end
			
			if (@hash_map[key].student_quiz.to_i > @quiz_max)
				@quiz_max = @hash_map[key].student_quiz.to_i
			end
			
			if (@hash_map[key].student_exam.to_i > @exam_max)
				@exam_max = @hash_map[key].student_exam.to_i
			end
			
			if (@hash_map[key].student_final.to_i > @final_max)
				@final_max = @hash_map[key].student_final.to_i
			end
		end
	end
# after the loop exits the true values of the averages are calculated
	@cla_avg = @cla_avg / @counter
	@ola_avg = @ola_avg / @counter
	@quiz_avg = @quiz_avg / @counter
	@exam_avg = @exam_avg / @counter
	@final_avg = @final_avg / @counter
end

# prompt for user with function calls
puts "Please give a file name"
userinput = gets.chomp
initialization()
storingObjects(userinput)
totalPointsFound()
userQuery()
maxAndAvg()

# newline for display and averages and maxs for user display
puts "\n"
puts "average " + @cla_avg.round(2).to_s + " " + @ola_avg.round(2).to_s  + " " + @quiz_avg.round(2).to_s + " " + @exam_avg.round(2).to_s  + " "  + @final_avg.round(2).to_s  
puts "highest " + @cla_max.round(2).to_s  + " " + @ola_max.round(2).to_s  + " " + @quiz_max.round(2).to_s  + " " + @exam_max.round(2).to_s  + " "  + @final_max.round(2).to_s  