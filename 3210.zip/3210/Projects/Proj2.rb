class Student
# The class must provide a function to calculate the #final letter grade.
	@studentID = 0
	@student_cla = 0
	@student_ola = 0
	@student_quiz = 0
	@student_exam  = 0
	@student_final = 0
	@student_total = 0
	@studnet_letter = " "
=begin
	if (student_total >= 90)
		student_letter = "A"
	else if (student_total >= 87 && student_total < 90)
		student_letter = "B+"
	else if (student_total >= 83 && student_total < 87)
		student_letter = "B"
	else if (student_total >= 80 && student_total < 83)
		student_letter = "B-"
	else if (student_total >= 77 && student_total < 80)
		student_letter = "C+"
	else if (student_total >= 73 && student_total < 77)
		student_letter = "C"
	else if (student_total >= 70 && student_total < 73)
		student_letter = "C-"
	else if (student_total >= 67 && student_total < 70)
		student_letter = "D+"
	else if (student_total >= 63 && student_total < 67)
		student_letter = "D"
	else if (student_total >= 60 && student_total < 63)
		student_letter = "D-"
	else
		student_letter = "F"
		
=end
end


def initialization()
@hash_map = Hash.new
@counter = 0.0

@ola_avg = 0, @cla_avg = 0, @quiz_avg = 0, @exam_avg = 0, @final_avg = 0
@cla_max = 0, @ola_max = 0, @quiz_max = 0, @exam_max = 0, @final_max = 0

end

def totalPointsFound()
	@hash_map.each do |key, value|
		if(@hash_map[key].studentID != "C#")
			total = @hash_map[key].cla_score.to_i + hash_map[key].ola_score.to_i + @hash_map[key].quiz_score.to_i + 
				@hash_map[key].exam_score.to_i + @hash_map[key].exam_final_score.to_i
				
				@hash_map[key].points_sum = sum
				@hash_map[key].letter_grade(sum)
				
				end
		end
end

def storingObjects(givenfile)
		file = File.open(givenfile)
		
		file.each_line do |line|
			key, file_cla, file_ola, file_quiz, file_exam, file_final = line.chomp.split(" ", 6)
			stud = Student.new(student_cla, student_ola, student_quiz, student_exam, student_final)
			@hash_map[key] = stud
		end
end


def userQuery()
	for i in 1..2 do
		puts ("Enter a C#: ")
		number = gets.chomp()
		
		#wtf does this mean to_i means to integer to_s means to string
		right = "%s %s %s %s %s %s" %[@hash_map[number].studentID.to_s, 
									  @hash_map[number].cla_score.to_s,
									  @hash_map[number].ola_score.to_s,
									  @hash_map[number].quiz_score.to_s,
									  @hash_map[number].exam_score.to_s,
									 
                  @hash_map[number].file_exam_score.to_s,
									  @hash_map[number].letter_grade.to_s]
		puts right
	end
	
	@hash_map.each do |key, value|
		if (@hash_map[key].studentID != "C#")
			right = "%-15s %-5s %-5s %-5s %-5s %-5s" %[@hash_map[number].studentID.to_s, 
													  @hash_map[number].cla_score.to_s,
													  @hash_map[number].ola_score.to_s,
													  @hash_map[number].quiz_score.to_s,
													  @hash_map[number].exam_score.to_s,
													  @hash_map[number].file_exam_score.to_s,
													  @hash_map[number].letter_grade.to_s]
		puts right
		else	
			right = "%-15s %-5s %-5s %-5s %-5s %-5s" %[@hash_map[number].studentID.to_s, 					  
													  @hash_map[number].cla_score.to_s,
													  @hash_map[number].ola_score.to_s,
													  @hash_map[number].quiz_score.to_s,
													  @hash_map[number].exam_score.to_s,
													  @hash_map[number].file_exam_score.to_s,
													  @hash_map[number].letter_grade.to_s
]
			puts right
		end
		
		end
	end
	

def maxAndAvg()
	@hash_map.each do |key, value|
		if(@hash_map[key].studentID != "C#")
		@cla_avg += hash_map[number].cla_score.to_i
		@ola_avg += hash_map[number].ola_score.to_i
		@quiz_avg += hash_map[number].quiz_score.to_i
		@exam_avg += hash_map[number].exam_score.to_i
		@avg_final += hash_map[number].final_score.to_i
		@counter += 1
		
			if (@hash_map[key].cla_score.to_i > @cla_max)
				@cla_max  = @hash_map[key].cla_score.to_i
			end
			
			if (@hash_map[key].ola_score.to_i > @ola_max )
				@ola_max  = @hash_map[key].ola_score.to_i
			end
			
			if (@hash_map[key].quiz_score.to_i > @quiz_max)
				@quiz_max = @hash_map[key].quiz_score.to_i
			end
			
			if (@hash_map[key].exam_score.to_i > @exam_max)
				@exam_max = @hash_map[key].exam_score.to_i
			end
			
			if (@hash_map[key].final_score.to_i > @final_max)
				@final_max = @hash_map[key].final_score.to_i
			end
		end
	end
end
			
	
	
	