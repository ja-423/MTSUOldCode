#lang racket

;Jaylon Atkins, CSCI 3210 Project 4
;Due Date: 10/6/21

;Write a non-recursive Scheme function area(r) that given 
;the radius r of a circle, computes its area as 3.14 * r * r.

(define PI 3.14)
(define(area r)
(* PI r r))


;Write a recursive Scheme function power(A, B) that takes two integer parameters, A and B, and 
;returns A raised to the B power. A must be a positive value, but B maybe a negative value.
;else (B is negative) return 1 / A * recursive call B-1
(define(power A B)
(cond
((= B 0) 1)
((> B 0 ) ( * A ( power A (- B 1) ) ) )
((= B -1) (/ 1 A ))
(else ( / (power A (+ B 1 ) ) A ) ) ) ) 

;Write a recursive Scheme function countZero(list) that returns the number of value zeros in 
;a given simple list of numbers. For example, (countZero ‘(1 0 2 3 0)) should return 2.

(define(countZero list)
(cond
((null? list)
 0)
((= (car list) 0)
(+ 1 (countZero (cdr list) ) ) )
(else (countZero (cdr list ) ) ) ) )
;Write a recursive Scheme function reverse(list) that returns the reverse of its simple 
;list parameter. For example, (reverse ‘(1 2 3 a b)) should return ‘(b a 3 2 1).

(define (reverse List)
(if (null? List)
'()
(append (reverse (cdr List)) (list (car List) ) ) ) ) 

;Write a recursive Scheme function palindrome(list) that returns true if the 
;simple list reads the same forward and backward; otherwise returns false. For example,
;(palindrome ‘(a 1 b 1 a)) returns true, while (palindrome ‘(a b)) returns false.

(define(palindrome List)
(cond
((null? List) true)
(( equal? List (reverse List)) true)
(else false))
)

;Write a recursive Scheme function merge(firstNameList, lastNamelist) that receives 
;a simple list of first names and a simple list of last names, and merges the two 
;lists into one list consisting of (firstName lastName) pairs.

(define(merge firstNameList lastNameList)
(cond
((null? firstNameList)
'() )
((null? lastNameList)
'() )
(else (cons (list (car firstNameList) (car lastNameList)) (merge (cdr firstNameList) (cdr lastNameList) ) ) ) )  )