%Project 5, Jaylon Atkins, 3210

%make sure to comment and re do variables

% Problem #1 mymember Good
mymember([]):- false.
mymember(X, [X]):- true.
mymember(X, [_|Y]):- mymember(X, Y).

% Problem #2 myeven Good
myeven(A_number):- A_number mod 2 =:= 0.


% Problem #3 myevennumber Good

myevennumber(0, []).
myevennumber(A_number, [H | T]) :- myeven(H), myevennumber(A_number1, T), A_number is A_number1 + 1, !.
myevennumber(A_number, [T]) :- myevennumber(A_number1, T), A_number is A_number1.



%Problem 4 good

myminlist([X], X).
myminlist([H|T], Minimum_value):- myminlist(T, Minimum_value1),
(H < Minimum_value1 -> Minimum_value is H; Minimum_value is Minimum_value1).

% Problem #5 good
palindrome([_]) :- !.
palindrome([_]) :- !.

%recursive conditions
palindrome([Head | Tail]) :- append(Mid, [Head], Tail), palindrome(Mid), !.


% Problem 6 good
leafcount(t(_, nil, nil), 1):- !.
leafcount(nil, 0):- !.
leafcount(t(_, L, R), X):- leafcount(L, X1), leafcount(R, X2), X is X1 + X2.
