I will see if I can find the assets from this class to properly load the project but the file "ProjectImage.png" is the general idea of the project.
This was completed last fall and took the second half of the semster to complete with my classmate Malachi.
