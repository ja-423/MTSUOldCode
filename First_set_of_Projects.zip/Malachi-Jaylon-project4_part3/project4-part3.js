/* Project 4 Part III.
 * Authors: Malachi Hughes and Jaylon Atkins
 */
var canvas, gl, program;
var pointsArray = [];
var normalsArray = [];
var texCoordsArray = [];
var shakerVertices = [];

//from extruded.js
var shape="circle";
var N;
var N_Triangle;
var N_Circle;
var BarnNumVertices = 48;

//variables that control the orthographic projection bounds.
var y_max = 5;
var y_min = -5;
var x_max = 8;
var x_min = -8;
var near = -50;
var far = 50;

//controls for animations
var xAxis = 0;
var yAxis = 1;
var zAxis = 2;
var axis = 1;
var theta =[0, 0, 0];
var thetaLoc;
var a_flag = false;
var t_flag = true;
var switchRot = 10;

//textures and sounds
var texture1, texture2, texture3, texture4,
texture5, texture6, texture7, texture8;
var sounds = [];

//light and material variables
var lightPosition = vec4(-1, 7, 15, 1 );
var lightAmbient = vec4(1, 250/255, 230/255, 1.0 );
var lightDiffuse = vec4(1, 250/255, 230/255, 1.0 );
var lightSpecular = vec4( 1, 1, 1, 1.0 );
var materialAmbient = vec4( .2, .2, .2, 1.0 );
var materialDiffuse = vec4( 0.0, 0.5, 1, 1.0);
var materialSpecular = vec4( 1, 1, 1, 1.0 );
var materialShininess = 50.0;

var modelViewMatrix, projectionMatrix;
var modelViewMatrixLoc, projectionMatrixLoc;
var modelViewStack=[];

window.onload = function init() {
    canvas = document.getElementById( "gl-canvas" );

    gl = WebGLUtils.setupWebGL( canvas );
    if ( !gl ) { alert( "WebGL isn't available" ); }

    gl.viewport( 0, 0, canvas.width, canvas.height );

    gl.clearColor( 0, 0, 0, 1.0 );

    gl.enable(gl.DEPTH_TEST);

    //  Load shaders and initialize attribute buffers
    program = initShaders( gl, "vertex-shader", "fragment-shader" );
    gl.useProgram( program );

    //generate all our points
    generateCube();
    generateCup();
    generateShaker();
    generateBarn();
    //generateLightPoint();

    //pass data to the GPU
    SendData();

    thetaLoc = gl.getUniformLocation(program, "theta");
    modelViewMatrixLoc = gl.getUniformLocation( program, "modelViewMatrix" );
    projectionMatrixLoc = gl.getUniformLocation( program, "projectionMatrix" );

    //setup ligthing
    SetupLightingMaterial();

    //open all loaded textures
    openTextures();

    //create sound objects
    sounds.push(new Audio("pepper-grinding.mp3"));
    sounds.push(new Audio("light-switch-off.mp3"));
    sounds.push(new Audio("light-switch-on.mp3"));

    //UI controls
    SetupUserInterfaceControls();

    render();
}

//texture coordinates
var texCoords = [
  vec2(0, 0),
  vec2(0, 1),
  vec2(1, 1),
  vec2(1, 0)
];

//primitive
/*
      E ----  F
     /|     / |
    A ---  B  |
    | |    |  |
    | G----+- H
    |/     | /
    C------D/                 */
var cubePoints = [
  vec4(-1,  1,  1, 1.0 ),  // A (0)
  vec4( 1,  1,  1, 1.0 ),  // B (1)
  vec4(-1, -1,  1, 1.0 ),  // C (2)
  vec4( 1, -1,  1, 1.0 ), // D (3)
  vec4( -1, 1, -1, 1.0 ), // E (4)
  vec4( 1,  1, -1, 1.0 ), // F (5)
  vec4( -1,-1, -1, 1.0 ), // G (6)
  vec4( 1, -1, -1, 1.0 )  // H (7)
];

//polygonal mesh
var cupPoints = [
    vec4(0, 0, 0, 1.0),
    vec4(0, 0.5, 0, 1.0),
    vec4(0.5, 0, 0, 1.0),
    vec4(0.5, 0.5, 0, 1.0),
    vec4(0.75, 0, 0.25, 1.0),
    vec4(0.75, 0.5, 0.25, 1.0),
    vec4(0.75, 0, 0.5, 1.0),
    vec4(0.75, 0.5, 0.5, 1.0),
    vec4(0.5, 0, 0.75, 1.0),
    vec4(0.5, 0.5, 0.75, 1.0),
    vec4(0, 0, 0.75, 1.0),
    vec4(0, 0.5, 0.75, 1.0),
    vec4(-0.25, 0, 0.5, 1.0),
    vec4(-0.25, 0.5, 0.5, 1.0),
    vec4(-0.25, 0, 0.25, 1.0),
    vec4(-0.25, 0.5, 0.25, 1.0),
];

//surface of revolution
var shakerPoints = [
  [0,    .104, 0.0],
	[.028, .110, 0.0],
	[.032, .126, 0.0],
	[.028, .161, 0.0],
	[.055, .197, 0.0],
	[.060, .219, 0.0],
	[.062, .238, 0.0],
	[.064, .245, 0.0],
	[.066, .246, 0.0],
	[.068, .257, 0.0],
	[.070, .266, 0.0],
	[.072, .287, 0.0],
	[.074, .294, 0.0],
	[.076, .301, 0.0],
	[.078, .328, 0.0],
	[.080, .380, 0.0],
	[.082, .410, 0.0],
	[.084, .425, 0.0],
	[.085, .432, 0.0],
	[.090, .447, 0.0],
	[.097, .465, 0.0],
	[.103, .488, 0.0],
	[.106, .512, 0.0],
	[.110, .526, 0.0],
	[0, .525, 0.0],
];

//extruded shape
var barnPoints = [
        vec4(0, 0, 0, 1),   // A(0)
        vec4(1, 0, 0, 1),   // B(1)
        vec4(1, 1, 0, 1),   // C(2)
        vec4(0.5, 1.5, 0, 1), // D(3)
        vec4(0, 1, 0, 1),    // E(4)
        vec4(0, 0, 1, 1),    // F(5)
        vec4(1, 0, 1, 1),    // G(6)
        vec4(1, 1, 1, 1),    // H(7)
        vec4(0.5, 1.5, 1, 1),  // I(8)
        vec4(0, 1, 1, 1)     // J(9)
    ];

function pentagon(a, b, c, d, e) {
     var indices=[barnPoints[a], barnPoints[b], barnPoints[c], barnPoints[d], barnPoints[e]];
     var normal = Newell(indices);

     pointsArray.push(barnPoints[a]);
     normalsArray.push(normal);
     texCoordsArray.push(texCoords[0]);
     pointsArray.push(barnPoints[b]);
     normalsArray.push(normal);
     texCoordsArray.push(texCoords[1]);
     pointsArray.push(barnPoints[c]);
     normalsArray.push(normal);
     texCoordsArray.push(texCoords[2]);


     pointsArray.push(barnPoints[a]);
     normalsArray.push(normal);
     texCoordsArray.push(texCoords[0]);
     pointsArray.push(barnPoints[c]);
     normalsArray.push(normal);
     texCoordsArray.push(texCoords[2]);
     pointsArray.push(barnPoints[d]);
     normalsArray.push(normal);
     texCoordsArray.push(texCoords[3]);


     pointsArray.push(barnPoints[a]);
     normalsArray.push(normal);
     texCoordsArray.push(texCoords[0]);
     pointsArray.push(barnPoints[d]);
     normalsArray.push(normal);
     texCoordsArray.push(texCoords[1]);
     pointsArray.push(barnPoints[e]);
     normalsArray.push(normal);
     texCoordsArray.push(texCoords[2]);

}

//original quad function with string to specify which shape is using quad()
function quad(a, b, c, d, shape){
    if(shape == "cube"){
        var indices=[cubePoints[a], cubePoints[b], cubePoints[c], cubePoints[d]];
        var normal = Newell(indices);

        pointsArray.push(cubePoints[a]);
        normalsArray.push(normal);
        texCoordsArray.push(texCoords[0]);
        pointsArray.push(cubePoints[b]);
        normalsArray.push(normal);
        texCoordsArray.push(texCoords[1]);
        pointsArray.push(cubePoints[c]);
        normalsArray.push(normal);
        texCoordsArray.push(texCoords[2]);
        pointsArray.push(cubePoints[a]);
        normalsArray.push(normal);
        texCoordsArray.push(texCoords[0]);
        pointsArray.push(cubePoints[c]);
        normalsArray.push(normal);
        texCoordsArray.push(texCoords[2]);
        pointsArray.push(cubePoints[d]);
        normalsArray.push(normal);
        texCoordsArray.push(texCoords[3]);
    }else if(shape == "shaker"){
         var indices=[shakerVertices[a], shakerVertices[b], shakerVertices[c], shakerVertices[d]];
         var normal = Newell(indices);

         pointsArray.push(shakerVertices[a]);
         normalsArray.push(normal);
         texCoordsArray.push(texCoords[0]);
         pointsArray.push(shakerVertices[b]);
         normalsArray.push(normal);
         texCoordsArray.push(texCoords[1]);
         pointsArray.push(shakerVertices[c]);
         normalsArray.push(normal);
         texCoordsArray.push(texCoords[2]);
         pointsArray.push(shakerVertices[a]);
         normalsArray.push(normal);
         texCoordsArray.push(texCoords[0]);
         pointsArray.push(shakerVertices[c]);
         normalsArray.push(normal);
         texCoordsArray.push(texCoords[2]);
         pointsArray.push(shakerVertices[d]);
         normalsArray.push(normal);
         texCoordsArray.push(texCoords[3]);
    }else if(shape == "barn"){
        var indices=[barnPoints[a], barnPoints[b], barnPoints[c], barnPoints[d]];
        var normal = Newell(indices);

         pointsArray.push(barnPoints[a]);
         normalsArray.push(normal);
         texCoordsArray.push(texCoords[0]);
         pointsArray.push(barnPoints[b]);
         normalsArray.push(normal);
         texCoordsArray.push(texCoords[1]);
         pointsArray.push(barnPoints[c]);
         normalsArray.push(normal);
         texCoordsArray.push(texCoords[2]);

         pointsArray.push(barnPoints[a]);
         normalsArray.push(normal);
         texCoordsArray.push(texCoords[0]);
         pointsArray.push(barnPoints[c]);
         normalsArray.push(normal);
         texCoordsArray.push(texCoords[2]);
         pointsArray.push(barnPoints[d]);
         normalsArray.push(normal);
         texCoordsArray.push(texCoords[3]);

    }
}

function tri(a, b, c){
    var indices = [cupPoints[a], cupPoints[b], cupPoints[c]];
    var normal = Newell(indices);


    pointsArray.push(cupPoints[a]);
    normalsArray.push(normal);
    texCoordsArray.push(texCoords[0]);
    pointsArray.push(cupPoints[b]);
    normalsArray.push(normal);
    texCoordsArray.push(texCoords[1]);
    pointsArray.push(cupPoints[c]);
    normalsArray.push(normal);
    texCoordsArray.push(texCoords[2]);

}

function generateCube(){
  quad(2, 0, 1, 3, "cube");  // front
  quad(7, 5, 4, 6, "cube");  // back
  quad(3, 1, 5, 7, "cube");  // right
  quad(6, 4, 0, 2, "cube");  // left
  quad(7, 6, 2, 3, "cube"); // bottom
  quad(0, 4, 5, 1, "cube"); // top
}

function generateBarn(){
    quad(0, 5, 9, 4, "barn");   // AFJE left side
    quad(3, 4, 9, 8, "barn");   // DEJI left roof
    quad(2, 3, 8, 7, "barn");
    quad(1, 2, 7, 6, "barn");
    quad(0, 1, 6, 5, "barn");
    pentagon (5, 6, 7, 8, 9);  // FGHIJ back
    pentagon (0, 4, 3, 2, 1);  // ABCDE (clockwise) front
}

function generateCup(){
    tri(0, 1, 3);
    tri(3, 2, 0);
    tri(2, 3, 5);
    tri(5, 4, 2);
    tri(4, 5, 7);
    tri(7, 6, 4);
    tri(6, 7, 9);
    tri(9, 8, 6);
    tri(8, 9, 11);
    tri(11, 10, 8);
    tri(10, 11, 13);
    tri(13, 12, 10);
    tri(12, 13, 15);
    tri(15, 14, 12);
    tri(14, 15, 1);
    tri(1, 0, 14);
}

//used to generate salt and pepper shakers (surface of rev)
function generateShaker(){
	//Setup initial points matrix
	for (var i = 0; i<25; i++)
	{
		shakerVertices.push(vec4(shakerPoints[i][0], shakerPoints[i][1],
                                   shakerPoints[i][2], 1));
	}

	var r;
        var t=Math.PI/12;

        // sweep the original curve another "angle" degree
	for (var j = 0; j < 24; j++)
	{
                var angle = (j+1)*t;

                // for each sweeping step, generate 25 new points corresponding to the original points
		for(var i = 0; i < 25 ; i++ )
		{
		        r = shakerVertices[i][0];
                        shakerVertices.push(vec4(r*Math.cos(angle), shakerVertices[i][1], -r*Math.sin(angle), 1));
		}
	}

       var N=25;
       // shakerQuad strips are formed slice by slice (not layer by layer)
       for (var i=0; i<24; i++) // slices
       {
           for (var j=0; j<24; j++)  // layers
           {
		           quad(i*N+j, (i+1)*N+j, (i+1)*N+(j+1), i*N+(j+1), "shaker");
           }
       }
}

function drawCube(){
  modelViewStack.push(modelViewMatrix);
  gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));
  gl.drawArrays( gl.TRIANGLES, 0, 36);
  modelViewMatrix = modelViewStack.pop();
}

function drawCup(){
  modelViewStack.push(modelViewMatrix);
  gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));
  gl.drawArrays( gl.TRIANGLES, 36, 48);
  modelViewMatrix = modelViewStack.pop;
}

function drawShaker(){
  modelViewStack.push(modelViewMatrix);
  gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));
  gl.drawArrays( gl.TRIANGLES, 84, 24*24*6);
  modelViewMatrix = modelViewStack.pop;
}

function drawBarn(){
  modelViewStack.push(modelViewMatrix);
  gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));
  gl.drawArrays( gl.TRIANGLES, 3540, BarnNumVertices);
  modelViewMatrix = modelViewStack.pop();
}

function setRoom(){
  materialAmbient = vec4( .7, .7, .7, 1.0 );
  materialDiffuse = vec4( .7, .7, .7, 1.0);
  materialSpecular = vec4( 1,1,1, 1.0 );
    materialShininess=100;
    SetupLightingMaterial();

    gl.uniform1i(gl.getUniformLocation(program, "texture"), 0);
    gl.uniform1i(gl.getUniformLocation(program, "textureFlag"), 1); //toggle texture flag on

     //the walls
     modelViewStack.push(modelViewMatrix);
     modelViewMatrix = lookAt(eye, at, up);
     modelViewMatrix = mult(modelViewMatrix, translate(-15, 0, 0));
     modelViewMatrix = mult(modelViewMatrix, scale4(0.5, 10, 15));
     gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));
     drawCube();
     modelViewMatrix = modelViewStack.pop();

     modelViewStack.push(modelViewMatrix);
     modelViewMatrix = lookAt(eye, at, up);
     modelViewMatrix = mult(modelViewMatrix, translate(0, 0, -15));
     modelViewMatrix = mult(modelViewMatrix, rotate(-90, 0, 1, 0));
     modelViewMatrix = mult(modelViewMatrix, scale4(0.5, 10, 15));
     gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));
     drawCube();
     modelViewMatrix = modelViewStack.pop();

     materialAmbient = vec4( 71/255, 54/255, 33/255, 1.0);
     materialDiffuse = vec4( 71/255, 54/255, 33/255, 1.0);
     materialSpecular = vec4( 1, 1, 1, 1.0);
     materialShininess=95;
     SetupLightingMaterial();

     gl.uniform1i(gl.getUniformLocation(program, "texture"), 1);

     //floor
     modelViewStack.push(modelViewMatrix);
     modelViewMatrix = lookAt(eye, at, up);
     modelViewMatrix = mult(modelViewMatrix, translate(0, -9.5, 0));
     modelViewMatrix = mult(modelViewMatrix, scale4(15, 0.5, 15));
     gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));
     drawCube();
     modelViewMatrix = modelViewStack.pop();

     materialAmbient = vec4( .5, .5, .5, 1.0 );
     materialDiffuse = vec4( .5, .5, .5, 1.0);
     materialSpecular = vec4( 1, 1, 1, 1.0 );
       materialShininess=100;
       SetupLightingMaterial();

     gl.uniform1i(gl.getUniformLocation(program, "texture"), 4);

     //partition
     modelViewStack.push(modelViewMatrix);
     modelViewMatrix = lookAt(eye, at, up);
     modelViewMatrix = mult(modelViewMatrix, translate(1.5, 0, -13));
     modelViewMatrix = mult(modelViewMatrix, scale4(0.75, 10, 1.5));
     gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));
     drawCube();
     modelViewMatrix = modelViewStack.pop();

     gl.uniform1i(gl.getUniformLocation(program, "textureFlag"), 0);  //stop using texture
}

function setTable(){
    materialAmbient = vec4( .7, .7, .7, 1.0 );
    materialDiffuse = vec4( .7, .7, .7, 1.0);
    materialSpecular = vec4( 1, 1, 1, 1.0 );
    materialShininess=75;
    SetupLightingMaterial();

    gl.uniform1i(gl.getUniformLocation(program, "texture"), 3);
    gl.uniform1i(gl.getUniformLocation(program, "textureFlag"), 1); //toggle texture flag on
    //table top
    modelViewStack.push(modelViewMatrix);
    modelViewMatrix = lookAt(eye, at, up);
    modelViewMatrix = mult(modelViewMatrix, translate(0, -3.5, 0));
    modelViewMatrix = mult(modelViewMatrix, scale4(8, 0.25, 4));
    gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));
    drawCube();
    modelViewMatrix = modelViewStack.pop();

    gl.uniform1i(gl.getUniformLocation(program, "textureFlag"), 0);  //stop using texture

    materialAmbient = vec4( 31/255, 23/255, 13/255, 1.0);
    materialDiffuse = vec4( 31/255, 23/255, 13/255, 1.0);
    materialSpecular = vec4( 1, 1, 1, 1.0 );
    materialShininess=75;
    SetupLightingMaterial();
    //front left leg
    modelViewStack.push(modelViewMatrix);
    modelViewMatrix = lookAt(eye, at, up);
    modelViewMatrix = mult(modelViewMatrix, translate(-7.5, -6.25, 3.5));
    modelViewMatrix = mult(modelViewMatrix, scale4(0.25, 2.7, 0.25));
    gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));
    drawCube();
    modelViewMatrix = modelViewStack.pop();

    //back left leg
    modelViewStack.push(modelViewMatrix);
    modelViewMatrix = lookAt(eye, at, up);
    modelViewMatrix = mult(modelViewMatrix, translate(-7.5, -6.25, -3.5));
    modelViewMatrix = mult(modelViewMatrix, scale4(0.25, 2.7, 0.25));
    gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));
    drawCube();
    modelViewMatrix = modelViewStack.pop();

    //back right leg
    modelViewStack.push(modelViewMatrix);
    modelViewMatrix = lookAt(eye, at, up);
    modelViewMatrix = mult(modelViewMatrix, translate(7.5, -6.25, -3.5));
    modelViewMatrix = mult(modelViewMatrix, scale4(0.25, 2.7, 0.25));
    gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));
    drawCube();
    modelViewMatrix = modelViewStack.pop();

    //front right leg
    modelViewStack.push(modelViewMatrix);
    modelViewMatrix = lookAt(eye, at, up);
    modelViewMatrix = mult(modelViewMatrix, translate(7.5, -6.25, 3.5));
    modelViewMatrix = mult(modelViewMatrix, scale4(0.25, 2.7, 0.25));
    gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));
    drawCube();
    modelViewMatrix = modelViewStack.pop();
}

function setCups(){
    materialAmbient = vec4(.2, .2, .2, 1.0);
    materialDiffuse = vec4(.2, .2, .2, 1.0);
    materialSpecular = vec4( 1, 1, 1, 1.0 );
    materialShininess=85;
    SetupLightingMaterial();
    //draw cup
    modelViewStack.push(modelViewMatrix);
    modelViewMatrix = lookAt(eye, at, up);
    modelViewMatrix = mult(modelViewMatrix, translate(-5, -3.25, 1));
    modelViewMatrix = mult(modelViewMatrix, scale4(0.75, 2, 1));
    gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));
    drawCup();
    modelViewMatrix = modelViewStack.pop();

    //draw cup
    modelViewStack.push(modelViewMatrix);
    modelViewMatrix = lookAt(eye, at, up);
    modelViewMatrix = mult(modelViewMatrix, translate(4, -3.25, -2));
    modelViewMatrix = mult(modelViewMatrix, scale4(0.75, 2, 1));
    gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));
    drawCup();
    modelViewMatrix = modelViewStack.pop();

    //put drink inside of cups
    materialAmbient = vec4(165/255, 193/255, 235/255, 1.0);
    materialDiffuse = vec4(165/255, 193/255, 235/255, 1.0);
    materialSpecular = vec4( 1, 1, 1, 1.0 );
    materialShininess=50;
    SetupLightingMaterial();
    modelViewStack.push(modelViewMatrix);
    modelViewMatrix = lookAt(eye, at, up);
    modelViewMatrix = mult(modelViewMatrix, translate(4.2, -3.45, -1.63));
    modelViewMatrix = mult(modelViewMatrix, scale4(3, 2, 3));
    gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));
    drawShaker();
    modelViewMatrix = modelViewStack.pop();

    modelViewStack.push(modelViewMatrix);
    modelViewMatrix = lookAt(eye, at, up);
    modelViewMatrix = mult(modelViewMatrix, translate(-4.8, -3.43, 1.4));
    modelViewMatrix = mult(modelViewMatrix, scale4(3, 2, 3));
    gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));
    drawShaker();
    modelViewMatrix = modelViewStack.pop();
}

function setDoor(){
    //doors
    materialAmbient = vec4(.8, .8, .8, 1.0);
    materialDiffuse = vec4(.8, .8, .8, 1.0);
    materialSpecular = vec4( 1, 1, 1, 1.0);
    materialShininess=100;
    SetupLightingMaterial();

    gl.uniform1i(gl.getUniformLocation(program, "texture"), 2);
    gl.uniform1i(gl.getUniformLocation(program, "textureFlag"), 1); //toggle texture flag on
    modelViewStack.push(modelViewMatrix);
    modelViewMatrix = lookAt(eye, at, up);
    modelViewMatrix = mult(modelViewMatrix, translate(9, -2, -14.5));
    modelViewMatrix = mult(modelViewMatrix, rotate(-90, 0, 1, 0));
    modelViewMatrix = mult(modelViewMatrix, scale4(0.5, 7, 3.5));
    gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));
    drawCube();
    modelViewMatrix = modelViewStack.pop();

    modelViewStack.push(modelViewMatrix);
    modelViewMatrix = lookAt(eye, at, up);
    modelViewMatrix = mult(modelViewMatrix, translate(9, -2, -15.5));
    modelViewMatrix = mult(modelViewMatrix, rotate(-90, 0, 1, 0));
    modelViewMatrix = mult(modelViewMatrix, scale4(0.5, 7, 3.5));
    gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));
    drawCube();
    modelViewMatrix = modelViewStack.pop();

    gl.uniform1i(gl.getUniformLocation(program, "textureFlag"), 0); //stop using texture

    //push plates for doors
    materialAmbient = vec4(.4, .4, .4, 1.0);
    materialDiffuse = vec4(.4, .4, .4, 1.0);
    materialSpecular = vec4( 1, 1, 1, 1.0);
    materialShininess=7;
    SetupLightingMaterial();
    modelViewStack.push(modelViewMatrix);
    modelViewMatrix = lookAt(eye, at, up);
    modelViewMatrix = mult(modelViewMatrix, translate(6.1, -3, -14));
    modelViewMatrix = mult(modelViewMatrix, rotate(-90, 0, 1, 0));
    modelViewMatrix = mult(modelViewMatrix, scale4(0.1, 1.25, 0.4));
    gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));
    drawCube();
    modelViewMatrix = modelViewStack.pop();

    modelViewStack.push(modelViewMatrix);
    modelViewMatrix = lookAt(eye, at, up);
    modelViewMatrix = mult(modelViewMatrix, translate(6.1, -3, -16));
    modelViewMatrix = mult(modelViewMatrix, rotate(-90, 0, 1, 0));
    modelViewMatrix = mult(modelViewMatrix, scale4(0.1, 1.25, 0.4));
    gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));
    drawCube();
    modelViewMatrix = modelViewStack.pop();
}

function setLightSwitch(){
    //light plate
    materialAmbient = vec4(1, 1, 1, 1.0);
    materialDiffuse = vec4(1, 1, 1, 1.0);
    materialSpecular = vec4( 1, 1, 1, 1.0);
    materialShininess=100;
    SetupLightingMaterial();
    modelViewStack.push(modelViewMatrix);
    modelViewMatrix = lookAt(eye, at, up);
    modelViewMatrix = mult(modelViewMatrix, translate(3.5, -2, -14.5));
    modelViewMatrix = mult(modelViewMatrix, rotate(-90, 0, 1, 0));
    modelViewMatrix = mult(modelViewMatrix, scale4(0.2, 0.75, 0.5));
    gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));
    drawCube();
    modelViewMatrix = modelViewStack.pop();

    //light switch
    materialAmbient = vec4(.7, .7, .7, 1.0);
    materialDiffuse = vec4(.7, .7, .7, 1.0);
    materialSpecular = vec4( 1, 1, 1, 1.0);
    materialShininess=25;
    SetupLightingMaterial();
    modelViewStack.push(modelViewMatrix);
    modelViewMatrix = lookAt(eye, at, up);
    modelViewMatrix = mult(modelViewMatrix, translate(3.5, -2, -14.4));
    modelViewMatrix = mult(modelViewMatrix, rotate(-90, 0, 1, 0));
    modelViewMatrix = mult(modelViewMatrix, rotate(switchRot, 0, 0, 1));
    modelViewMatrix = mult(modelViewMatrix, scale4(0.2, 0.45, 0.15));
    gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));
    drawCube();
    modelViewMatrix = modelViewStack.pop();
}

function setPainting(){
  //doors
  materialAmbient = vec4(.8, .8, .8, 1.0);
  materialDiffuse = vec4(.8, .8, .8, 1.0);
  materialSpecular = vec4( 1, 1, 1, 1.0);
  materialShininess=100;
  SetupLightingMaterial();

  gl.uniform1i(gl.getUniformLocation(program, "texture"), 3);
  gl.uniform1i(gl.getUniformLocation(program, "textureFlag"), 1); //toggle texture flag on
  modelViewStack.push(modelViewMatrix);
  modelViewMatrix = lookAt(eye, at, up);
  modelViewMatrix = mult(modelViewMatrix, translate(-14.5, 2, -8));
  modelViewMatrix = mult(modelViewMatrix, scale4(0.25, 4, 3));
  gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));
  drawCube();
  modelViewMatrix = modelViewStack.pop();

  gl.uniform1i(gl.getUniformLocation(program, "texture"), 5);
  modelViewStack.push(modelViewMatrix);
  modelViewMatrix = lookAt(eye, at, up);
  modelViewMatrix = mult(modelViewMatrix, translate(-14.4, 2, -8));
  modelViewMatrix = mult(modelViewMatrix, scale4(0.2, 3.75, 2.75));
  gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));
  drawCube();
  modelViewMatrix = modelViewStack.pop();

  gl.uniform1i(gl.getUniformLocation(program, "textureFlag"), 0); //stop using textures
}

function setBar(){
    materialAmbient = vec4( 0, 0, 0, 1.0 );
    materialDiffuse = vec4( 0, 0, 0, 1.0);
    materialSpecular = vec4( 0,0,0, 1.0 );
    materialShininess=100;
    SetupLightingMaterial();

    //window
    modelViewStack.push(modelViewMatrix);
    modelViewMatrix = lookAt(eye, at, up);
    modelViewMatrix = mult(modelViewMatrix, translate(-7, 1, -15));
    modelViewMatrix = mult(modelViewMatrix, rotate(-90, 0, 1, 0));
    modelViewMatrix = mult(modelViewMatrix, scale4(0.52, 3, 6));
    gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));
    drawCube();
    modelViewMatrix = modelViewStack.pop();

    materialAmbient = vec4( .5, .5, .5, 1.0 );
    materialDiffuse = vec4( .5, .5, .5, 1.0);
    materialSpecular = vec4( .3, .3, .3, 1.0 );
    materialShininess=75;
    SetupLightingMaterial();

    //bar top
    gl.uniform1i(gl.getUniformLocation(program, "texture"), 6);
    gl.uniform1i(gl.getUniformLocation(program, "textureFlag"), 1); //toggle texture flag on

    modelViewStack.push(modelViewMatrix);
    modelViewMatrix = lookAt(eye, at, up);
    modelViewMatrix = mult(modelViewMatrix, translate(-7, -2, -15));
    modelViewMatrix = mult(modelViewMatrix, scale4(6, 0.25, 2.5));
    gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));
    drawCube();
    modelViewMatrix = modelViewStack.pop();

    gl.uniform1i(gl.getUniformLocation(program, "textureFlag"), 0);  //stop using texture

    materialAmbient = vec4(.2, .2, .2, 1.0);
    materialDiffuse = vec4(.2, .2, .2, 1.0);
    materialSpecular = vec4( 1, 1, 1, 1.0 );
    materialShininess=85;
    SetupLightingMaterial();

    //draw cup
    modelViewStack.push(modelViewMatrix);
    modelViewMatrix = lookAt(eye, at, up);
    modelViewMatrix = mult(modelViewMatrix, translate(-8, -1.75, -14));
    modelViewMatrix = mult(modelViewMatrix, scale4(0.75, 2, 1));
    gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));
    drawCup();
    modelViewMatrix = modelViewStack.pop();

    //put drink in cup
    materialAmbient = vec4(165/255, 193/255, 235/255, 1.0);
    materialDiffuse = vec4(165/255, 193/255, 235/255, 1.0);
    materialSpecular = vec4( .9, .9, .9, 1.0 );
    materialShininess=100;
    SetupLightingMaterial();
    modelViewStack.push(modelViewMatrix);
    modelViewMatrix = lookAt(eye, at, up);
    modelViewMatrix = mult(modelViewMatrix, translate(-7.8, -1.95, -13.63));
    modelViewMatrix = mult(modelViewMatrix, scale4(3, 2, 3));
    gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));
    drawShaker();
    modelViewMatrix = modelViewStack.pop();
}

function setCarpet(){
  materialAmbient = vec4( .7, .7, .7, 1.0 );
  materialDiffuse = vec4( .7, .7, .7, 1.0);
  materialSpecular = vec4( .4, .4, .4, 1.0 );
  materialShininess=100;
  SetupLightingMaterial();

  gl.uniform1i(gl.getUniformLocation(program, "texture"), 7);
  gl.uniform1i(gl.getUniformLocation(program, "textureFlag"), 1); //toggle texture flag on
  modelViewStack.push(modelViewMatrix);
  modelViewMatrix = lookAt(eye, at, up);
  modelViewMatrix = mult(modelViewMatrix, translate(0, -9, 0));
  modelViewMatrix = mult(modelViewMatrix, scale4(12, 0.1, 10));
  gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));
  drawCube();
  modelViewMatrix = modelViewStack.pop();

  gl.uniform1i(gl.getUniformLocation(program, "textureFlag"), 0);  //stop using texture
}

function setBirdhouse(){
    materialAmbient = vec4( 90/255, 72/255, 31/255, 1.0);
    materialDiffuse = vec4( 90/255, 72/255, 31/255, 1.0);
    materialSpecular = vec4( .5, .5, .5, 1.0 );
    materialShininess=20;
    SetupLightingMaterial();
    //bird house to go on shelf
    modelViewStack.push(modelViewMatrix);
    modelViewMatrix = lookAt(eye, at, up);
    modelViewMatrix = mult(modelViewMatrix, translate(-13.5, 2.75, 6));
    modelViewMatrix = mult(modelViewMatrix, rotate(90, 0, 1, 0));
    gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));
    drawBarn();
    modelViewMatrix = modelViewStack.pop();

    materialAmbient = vec4( 130/255, 102/255, 71/255, 1.0);
    materialDiffuse = vec4( 130/255, 102/255, 71/255, 1.0);
    materialSpecular = vec4( 1, 1, 1, 1.0 );
    materialShininess=50;
    SetupLightingMaterial();

    //hole for birdhouse
    modelViewStack.push(modelViewMatrix);
    modelViewMatrix = lookAt(eye, at, up);
    modelViewMatrix = mult(modelViewMatrix, translate(-13, 3.25, 5.5));
    modelViewMatrix = mult(modelViewMatrix, rotate(-90, 0, 0, 1));
    modelViewMatrix = mult(modelViewMatrix, scale4(2, 1, 2));
    gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));
    drawShaker();
    modelViewMatrix = modelViewStack.pop();
}

function setShelf(){
    materialAmbient = vec4( .7, .7, .7, 1.0 );
    materialDiffuse = vec4( .7, .7, .7, 1.0);
    materialSpecular = vec4( 1, 1, 1, 1.0 );
    materialShininess=75;
    SetupLightingMaterial();

    gl.uniform1i(gl.getUniformLocation(program, "texture"), 3);
    gl.uniform1i(gl.getUniformLocation(program, "textureFlag"), 1); //toggle texture flag on

    //draw shelf
    modelViewStack.push(modelViewMatrix);
    modelViewMatrix = lookAt(eye, at, up);
    modelViewMatrix = mult(modelViewMatrix, translate(-13.5, 2.5, 4));
    modelViewMatrix = mult(modelViewMatrix, rotate(90, 0, 1, 0));
    modelViewMatrix = mult(modelViewMatrix, scale4(5, 0.25, 1));
    gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));
    drawCube();
    modelViewMatrix = modelViewStack.pop();

    gl.uniform1i(gl.getUniformLocation(program, "textureFlag"), 0);  //stop using texture
}

var at = vec3(0, 0, 0);
var up = vec3(0, 1, 0);
var eye = vec3(2, 2, 2);
var render = function() {

    gl.clear( gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

    //Change view using mouse movements
    projectionMatrix = ortho( x_min*AllInfo.zoomFactor - AllInfo.translateX,
                              x_max*AllInfo.zoomFactor - AllInfo.translateX,
                            y_min*AllInfo.zoomFactor - AllInfo.translateY,
                              y_max*AllInfo.zoomFactor - AllInfo.translateY,
                            near, far);
    gl.uniformMatrix4fv(projectionMatrixLoc, false, flatten(projectionMatrix));

    // Setup the eye to move around different points on a sphere
    eye = vec3( AllInfo.radius*Math.cos(AllInfo.phi),
                AllInfo.radius*Math.sin(AllInfo.theta),
               AllInfo.radius*Math.sin(AllInfo.phi));

    setRoom();

    setDoor();

    setLightSwitch();

    setCups();

    setTable();

    setPainting();

    setBar();

    setCarpet();

    setBirdhouse();

    setShelf();

    //animation for shakers
    if(a_flag) {
      theta[axis] += 0.1;

      materialAmbient = vec4( 1, 1, 1, 1.0);
      materialDiffuse = vec4( 1, 1, 1, 1.0);
      materialSpecular = vec4( 1, 1, 1, 1.0 );
      materialShiness=90;
      SetupLightingMaterial();
      //draw salt shaker
      modelViewStack.push(modelViewMatrix);
      modelViewMatrix = lookAt(eye, at, up);
      modelViewMatrix = mult(modelViewMatrix, translate(-0.5, -1.75, 0));
      modelViewMatrix = mult(modelViewMatrix, rotate(180, 1, 0, 0));
      modelViewMatrix = mult(modelViewMatrix, rotate(theta[xAxis], [1, 0, 0] ));
      modelViewMatrix = mult(modelViewMatrix, rotate(theta[yAxis], [0, 1, 0] ));
      modelViewMatrix = mult(modelViewMatrix, rotate(theta[zAxis], [0, 0, 1] ));
      modelViewMatrix = mult(modelViewMatrix, scale4(3, 3, 3));
      gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));
      drawShaker();
      modelViewMatrix = modelViewStack.pop();

      materialAmbient = vec4( 0, 0, 0, 1.0);
      materialDiffuse = vec4( 0, 0, 0, 1.0);
      materialSpecular = vec4( 1, 1, 1, 1.0 );
      materialShiness=90;
      SetupLightingMaterial();
      //draw pepper shaker
      modelViewStack.push(modelViewMatrix);
      modelViewMatrix = lookAt(eye, at, up);
      modelViewMatrix = mult(modelViewMatrix, translate(0.5, -1.75, 0));
      modelViewMatrix = mult(modelViewMatrix, rotate(180, 1, 0, 0));
      modelViewMatrix = mult(modelViewMatrix, rotate(theta[xAxis], [1, 0, 0] ));
      modelViewMatrix = mult(modelViewMatrix, rotate(theta[yAxis], [0, 1, 0] ));
      modelViewMatrix = mult(modelViewMatrix, rotate(theta[zAxis], [0, 0, 1] ));
      modelViewMatrix = mult(modelViewMatrix, scale4(3, 3, 3));
      gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));
      drawShaker();
      modelViewMatrix = modelViewStack.pop();

      requestAnimationFrame(render);
    }else{
      sounds[0].pause();
      materialAmbient = vec4( 1, 1, 1, 1.0);
      materialDiffuse = vec4( 1, 1, 1, 1.0);
      materialSpecular = vec4( 1, 1, 1, 1.0 );
      materialShiness=100;
      SetupLightingMaterial();
      //draw salt shaker
      modelViewStack.push(modelViewMatrix);
      modelViewMatrix = lookAt(eye, at, up);
      modelViewMatrix = mult(modelViewMatrix, translate(-0.5, -1.75, 0));
      modelViewMatrix = mult(modelViewMatrix, rotate(180, 1, 0, 0));
      modelViewMatrix = mult(modelViewMatrix, scale4(3, 3, 3));
      gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));
      drawShaker();
      modelViewMatrix = modelViewStack.pop();

      materialAmbient = vec4( 0, 0, 0, 1.0);
      materialDiffuse = vec4( 0, 0, 0, 1.0);
      materialSpecular = vec4( 1, 1, 1, 1.0 );
      materialShiness=100;
      SetupLightingMaterial();
      //draw pepper shaker
      modelViewStack.push(modelViewMatrix);
      modelViewMatrix = lookAt(eye, at, up);
      modelViewMatrix = mult(modelViewMatrix, translate(0.5, -1.75, 0));
      modelViewMatrix = mult(modelViewMatrix, rotate(180, 1, 0, 0));
      modelViewMatrix = mult(modelViewMatrix, scale4(3, 3, 3));
      gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));
      drawShaker();
      modelViewMatrix = modelViewStack.pop();
    }

}

//---------All Supporting Functions----------
function SendData(){
    // pass data onto GPU
    var nBuffer = gl.createBuffer();
    gl.bindBuffer( gl.ARRAY_BUFFER, nBuffer);
    gl.bufferData( gl.ARRAY_BUFFER, flatten(normalsArray), gl.STATIC_DRAW );

    var vNormal = gl.getAttribLocation( program, "vNormal" );
    gl.vertexAttribPointer( vNormal, 3, gl.FLOAT, false, 0, 0 );
    gl.enableVertexAttribArray( vNormal);

    var vBuffer = gl.createBuffer();
    gl.bindBuffer( gl.ARRAY_BUFFER, vBuffer );
    gl.bufferData( gl.ARRAY_BUFFER, flatten(pointsArray), gl.STATIC_DRAW );

    var vPosition = gl.getAttribLocation( program, "vPosition" );
    gl.vertexAttribPointer( vPosition, 4, gl.FLOAT, false, 0, 0 );
    gl.enableVertexAttribArray( vPosition );

    // set up texture buffer
    var tBuffer = gl.createBuffer();
    gl.bindBuffer( gl.ARRAY_BUFFER, tBuffer );
    gl.bufferData( gl.ARRAY_BUFFER, flatten(texCoordsArray), gl.STATIC_DRAW );

    var vTexCoord = gl.getAttribLocation( program, "vTextureCoord" );
    gl.vertexAttribPointer( vTexCoord, 2, gl.FLOAT, false, 0, 0 );
    gl.enableVertexAttribArray( vTexCoord );
}

function SetupLightingMaterial(){
    // set up lighting and material
    ambientProduct = mult(lightAmbient, materialAmbient);
    diffuseProduct = mult(lightDiffuse, materialDiffuse);
    specularProduct = mult(lightSpecular, materialSpecular);

	// send lighting and material coefficient products to GPU
    gl.uniform4fv( gl.getUniformLocation(program, "ambientProduct"),flatten(ambientProduct) );
    gl.uniform4fv( gl.getUniformLocation(program, "diffuseProduct"),flatten(diffuseProduct) );
    gl.uniform4fv( gl.getUniformLocation(program, "specularProduct"),flatten(specularProduct) );
    gl.uniform4fv( gl.getUniformLocation(program, "lightPosition"),flatten(lightPosition) );
    gl.uniform1f( gl.getUniformLocation(program, "shininess"),materialShininess );
}

// Load a new texture
function loadNewTexture(texture, whichTex){
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
    gl.activeTexture(whichTex);
    gl.bindTexture(gl.TEXTURE_2D, texture);
    gl.texImage2D( gl.TEXTURE_2D, 0, gl.RGB, gl.RGB, gl.UNSIGNED_BYTE, texture.image );
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri( gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST );
    gl.texParameteri( gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST );
}

// Setup the new image object prior to loading to the shaders
function openTextures(){
	  texture1 = gl.createTexture();
    texture1.image = new Image();
    texture1.image.src= "navy-wall.jpg";
    texture1.image.onload = function() {loadNewTexture(texture1, gl.TEXTURE0);}

    texture2 = gl.createTexture();
    texture2.image = new Image();
    texture2.image.src= "floor.jpg";
    texture2.image.onload = function() {loadNewTexture(texture2, gl.TEXTURE1);}

    texture3 = gl.createTexture();
    texture3.image = new Image();
    texture3.image.src= "door.jpg";
    texture3.image.onload = function() {loadNewTexture(texture3, gl.TEXTURE2);}

    texture4 = gl.createTexture();
    texture4.image = new Image();
    texture4.image.src= "table.jpg";
    texture4.image.onload = function() {loadNewTexture(texture4, gl.TEXTURE3);}

    texture5 = gl.createTexture();
    texture5.image = new Image();
    texture5.image.src= "partition.jpg";
    texture5.image.onload = function() {loadNewTexture(texture5, gl.TEXTURE4);}

    texture6 = gl.createTexture();
    texture6.image = new Image();
    texture6.image.src= "painting1.jpg";
    texture6.image.onload = function() {loadNewTexture(texture6, gl.TEXTURE5);}

    texture7 = gl.createTexture();
    texture7.image = new Image();
    texture7.image.src= "countertop.jpg";
    texture7.image.onload = function() {loadNewTexture(texture7, gl.TEXTURE6);}

    texture8 = gl.createTexture();
    texture8.image = new Image();
    texture8.image.src= "carpet.png";
    texture8.image.onload = function() {loadNewTexture(texture8, gl.TEXTURE7);}
}

//setup UI controls for keypresses and camera controls
function SetupUserInterfaceControls(){
  // Set the scroll wheel to change the zoom factor.
  document.getElementById("gl-canvas").addEventListener("wheel", function(e) {
      if (e.wheelDelta > 0) {
          AllInfo.zoomFactor = Math.max(0.1, AllInfo.zoomFactor - 0.1);
      } else {
          AllInfo.zoomFactor += 0.1;
      }
      render();
  });

  //add event listeners for key presses
  window.addEventListener("keydown", function () {
    if (event.keyCode == 65) { //if 'A' or 'a' is pressed, trigger animation
      a_flag = !a_flag;
      sounds[0].play();
    }
    if (event.keyCode == 84){ //if 'T' or 't' is pressed, turn light off or on
      t_flag = !t_flag;
      if(t_flag){
        sounds[2].play();
        switchRot = 10;
        lightAmbient = vec4(1, 250/255, 230/255, 1.0 );
        lightDiffuse = vec4(1, 250/255, 230/255, 1.0 );
        lightSpecular = vec4( 1, 1, 1, 1.0 );
      }
      else{
        sounds[1].play();
        switchRot = -10;
        lightAmbient = vec4(.1, .1, .1, 1.0 );
        lightDiffuse = vec4(.1, .1, .1, 1.0 );
        lightSpecular = vec4(0, 0, 0, 1.0);
      }
    }
    if (event.keyCode == 66){
      t_flag = true;
      a_flag = false;
      lightAmbient = vec4(1, 250/255, 230/255, 1.0 );
      lightDiffuse = vec4(1, 250/255, 230/255, 1.0 );
      lightSpecular = vec4( 1, 1, 1, 1.0 );
      switchRot = 10;
      at = vec3(0, 0, 0);
      up = vec3(0, 1, 0);
      eye = vec3(2, 2, 2);
      y_max = 5;
      y_min = -5;
      x_max = 8;
      x_min = -8;
      near = -50;
      far = 50;
    }

    render();
  });

  //************************************************************************************
  //* When you click a mouse button, set it so that only that button is seen as
  //* pressed in AllInfo. Then set the position. The idea behind this and the mousemove
  //* event handler's functionality is that each update we see how much the mouse moved
  //* and adjust the camera value by that amount.
  //************************************************************************************
  document.getElementById("gl-canvas").addEventListener("mousedown", function(e) {
      if (e.which == 1) {
          AllInfo.mouseDownLeft = true;
          AllInfo.mouseDownRight = false;
          AllInfo.mousePosOnClickY = e.y;
          AllInfo.mousePosOnClickX = e.x;
      } else if (e.which == 3) {
          AllInfo.mouseDownRight = true;
          AllInfo.mouseDownLeft = false;
          AllInfo.mousePosOnClickY = e.y;
          AllInfo.mousePosOnClickX = e.x;
      }
      render();
  });

  document.addEventListener("mouseup", function(e) {
      AllInfo.mouseDownLeft = false;
      AllInfo.mouseDownRight = false;
      render();
  });

  document.addEventListener("mousemove", function(e) {
      if (AllInfo.mouseDownRight) {
          AllInfo.translateX += (e.x - AllInfo.mousePosOnClickX)/30;
          AllInfo.mousePosOnClickX = e.x;

          AllInfo.translateY -= (e.y - AllInfo.mousePosOnClickY)/30;
          AllInfo.mousePosOnClickY = e.y;
      } else if (AllInfo.mouseDownLeft) {
          AllInfo.phi += (e.x - AllInfo.mousePosOnClickX)/100;
          AllInfo.mousePosOnClickX = e.x;

          AllInfo.theta += (e.y - AllInfo.mousePosOnClickY)/100;
          AllInfo.mousePosOnClickY = e.y;
      }
      render();
  });
}

// namespace contain all the project information for camera and mouse controls
var AllInfo = {

    // Camera pan control variables.
    zoomFactor : 4,
    translateX : 0,
    translateY : 0,

    // Camera rotate control variables.
    phi : 1,
    theta : 0.5,
    radius : 1,
    dr : 2.0 * Math.PI/180.0,

    // Mouse control variables
    mouseDownRight : false,
    mouseDownLeft : false,

    mousePosOnClickX : 0,
    mousePosOnClickY : 0
};

function scale4(a, b, c) {
    var result = mat4();
    result[0][0] = a;
    result[1][1] = b;
    result[2][2] = c;
    return result;
}

//Newell's method to calculate normals for the lighting
function Newell(indices){
   var L=indices.length;
   var x=0, y=0, z=0;
   var index, nextIndex;

   for (var i=0; i<L; i++)
   {
       index=i;
       nextIndex = (i+1)%L;

       x += (indices[index][1] - indices[nextIndex][1])*
            (indices[index][2] + indices[nextIndex][2]);
       y += (indices[index][2] - indices[nextIndex][2])*
            (indices[index][0] + indices[nextIndex][0]);
       z += (indices[index][0] - indices[nextIndex][0])*
            (indices[index][1] + indices[nextIndex][1]);
   }


   return (normalize(vec3(x, y, z)));
}

function ExtrudedShape(){
    var basePoints=[];
    var topPoints=[];

    // create the face list
    // add the side faces first --> N quads
    for (var j=0; j<N; j++)
    {
        quad(j, j+N, (j+1)%N+N, (j+1)%N, "barn");
    }

    // the first N shakerVertices come from the base
    basePoints.push(0);
    for (var i=N-1; i>0; i--)
    {
        basePoints.push(i);  // index only
    }
    // add the base face as the Nth face
    polygon(basePoints);

    // the next N shakerVertices come from the top
    for (var i=0; i<N; i++)
    {
        topPoints.push(i+N); // index only
    }
    // add the top face
    polygon(topPoints);
}
