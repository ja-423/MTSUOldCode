var gl, points;

function main() {
    // Creates the canvas for display on screen

    var canvas = document.getElementById( "gl-canvas" );
    
    // Error Statement if WebGL is working improperly
    gl = WebGLUtils.setupWebGL( canvas );
    if ( !gl ) { alert( "WebGL isn't available" ); }

    //  Load shaders and initialize attribute buffers
    var program = initShaders( gl, "vertex-shader", "fragment-shader" );
    gl.useProgram( program );
    
    // Four Vertices
    var vertices = [

    // First triangle of the square of the top left this is a right triangle
        vec2(-0.25, -0.25),
        vec2(-0.25,  0.25),
        vec2(0.25, -0.25),

    // Second triangle of the square of the top left this is a right triangle
        vec2(0.25,  0.25),
        vec2(-0.25, 0.25),
        vec2(0.25, -0.25),
    
    // These vertices create the equilateral triangle to the top right of the program
        vec2(0.25, -0.25),
        vec2(0.5, 0.25),
        vec2(0.75, -0.25),
    
    // These vertices create a right angle triangle for the bottom left square.
    // This triangle is the right side of the the square

        vec2(0.75, -0.25),
        vec2(0.75, -0.75),
        vec2(0.25, -0.25),

    // These vertices create a right angle triangle for the bottom left square.
    // This triangle is the left side of the the square

        vec2(0.25, -0.25),
        vec2(0.25, -0.75),
        vec2(0.75, -0.75),

    // This is the last equilateral triangle on the bottom left
        vec2(-0.25, -0.75),
        vec2(0, -0.25),
        vec2(0.25, -0.75),
    ];
   
    // Load the data into the GPU
    var bufferId = gl.createBuffer();
    gl.bindBuffer( gl.ARRAY_BUFFER, bufferId );
    gl.bufferData( gl.ARRAY_BUFFER, flatten(vertices), gl.STATIC_DRAW );

    // Associate out shader variables with our data buffer
    var vPosition = gl.getAttribLocation( program, "vPosition" );
    gl.vertexAttribPointer( vPosition, 2, gl.FLOAT, false, 0, 0 );
    gl.enableVertexAttribArray( vPosition );

    render();
};

// Renders the given objects in the parameters given such as TRIANGLGES AND the proper
// Gradient and transparency 
function render() {
    gl.clearColor( 0.0, 0.0, 0.0, 1.0 );
    gl.clear( gl.COLOR_BUFFER_BIT );
    gl.drawArrays(gl.TRIANGLES, 0, 18);
}
