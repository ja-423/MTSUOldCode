/*Jaylon Atkins
CSCI 3110-001 (your section #)
Project #05
Due: 03/25/21
*/

#include <iostream>
#include <string>
#include "treasuremap.h"
using namespace std;

int main()
{
ifstream fancyfile;
fancyfile.open("treasuremap.txt");

string numbers, map;
int rows, col;

fancyfile >> numbers >> rows >> col;

for(int i = 0; i < col; i++)
{
    fancyfile >> map;
    cout << map;
}

//“Treasure Found!” or “No treasure!”

}