var canvas, gl;

var numcubeVertices  = 36;
var pointsArray = [];
var colorsArray = [];

// Variables that control the orthographic projection bounds.
var y_max = 5;
var y_min = -5;
var x_max = 8;
var x_min = -8;
var near = -50;
var far = 50;

var modelViewMatrix, projectionMatrix;
var modelViewMatrixLoc, projectionMatrixLoc;
var modelViewStack=[];


/*
      E ----  F
     /|     / |
    A ---  B  |
    | |    |  |
    | G----+- H
    |/     | /
    C------D/                 */
var cubeVertices = [
    vec4(-1,  1,  1, 1.0 ),  // A (0)
    vec4( 1,  1,  1, 1.0 ),  // B (1)
    vec4(-1, -1,  1, 1.0 ),  // C (2)
    vec4( 1, -1,  1, 1.0 ), // D (3)
    vec4( -1, 1, -1, 1.0 ), // E (4)
    vec4( 1,  1, -1, 1.0 ), // F (5)
    vec4( -1,-1, -1, 1.0 ), // G (6)
    vec4( 1, -1, -1, 1.0 ),  // H (7)
];

var cupVertices = [
    vec4(0, 0, 0, 1.0),
    vec4(0, 0.5, 0, 1.0),
    vec4(0.5, 0, 0, 1.0),
    vec4(0.5, 0.5, 0, 1.0),
    vec4(0.75, 0, 0.25, 1.0),
    vec4(0.75, 0.5, 0.25, 1.0),
    vec4(0.75, 0, 0.5, 1.0),
    vec4(0.75, 0.5, 0.5, 1.0),
    vec4(0.5, 0, 0.75, 1.0),
    vec4(0.5, 0.5, 0.75, 1.0),
    vec4(0, 0, 0.75, 1.0),
    vec4(0, 0.5, 0.75, 1.0),
    vec4(-0.25, 0, 0.5, 1.0),
    vec4(-0.25, 0.5, 0.5, 1.0),
    vec4(-0.25, 0, 0.25, 1.0),
    vec4(-0.25, 0.5, 0.25, 1.0),

]

var cubeColors = [
    vec4( 0.25, 0.17, 0.05, 1.0 ),  // brown
    vec4( 0.45, 0.37, 0.25, 1.0 ),  // light brown
];

var cupColors = [
    vec4(0.35, 0.60, 0.74, 1.0),
    vec4(0.08, 0.47, 0.55, 1.0)
]



// quad uses first index to set color for face
function generateCube(){
     pointsArray.push(cubeVertices[0]);
     colorsArray.push(cubeColors[0]);
     pointsArray.push(cubeVertices[2]);
     colorsArray.push(cubeColors[0]);
     pointsArray.push(cubeVertices[3]);
     colorsArray.push(cubeColors[0]);
     pointsArray.push(cubeVertices[1]);
     colorsArray.push(cubeColors[0]);

     pointsArray.push(cubeVertices[1]);
     colorsArray.push(cubeColors[1]);
     pointsArray.push(cubeVertices[3]);
     colorsArray.push(cubeColors[1]);
     pointsArray.push(cubeVertices[7]);
     colorsArray.push(cubeColors[1]);
     pointsArray.push(cubeVertices[5]);
     colorsArray.push(cubeColors[1]);

     pointsArray.push(cubeVertices[5]);
     colorsArray.push(cubeColors[0]);
     pointsArray.push(cubeVertices[7]);
     colorsArray.push(cubeColors[0]);
     pointsArray.push(cubeVertices[6]);
     colorsArray.push(cubeColors[0]);
     pointsArray.push(cubeVertices[4]);
     colorsArray.push(cubeColors[0]);

     pointsArray.push(cubeVertices[4]);
     colorsArray.push(cubeColors[0]);
     pointsArray.push(cubeVertices[6]);
     colorsArray.push(cubeColors[0]);
     pointsArray.push(cubeVertices[2]);
     colorsArray.push(cubeColors[0]);
     pointsArray.push(cubeVertices[0]);
     colorsArray.push(cubeColors[0]);

     pointsArray.push(cubeVertices[0]);
     colorsArray.push(cubeColors[0]);
     pointsArray.push(cubeVertices[1]);
     colorsArray.push(cubeColors[0]);
     pointsArray.push(cubeVertices[5]);
     colorsArray.push(cubeColors[0]);
     pointsArray.push(cubeVertices[4]);
     colorsArray.push(cubeColors[0]);

     pointsArray.push(cubeVertices[6]);
     colorsArray.push(cubeColors[0]);
     pointsArray.push(cubeVertices[2]);
     colorsArray.push(cubeColors[0]);
     pointsArray.push(cubeVertices[3]);
     colorsArray.push(cubeColors[0]);
     pointsArray.push(cubeVertices[7]);
     colorsArray.push(cubeColors[0]);
}

function generateCup(){
    pointsArray.push(cupVertices[0]);
    colorsArray.push(cupColors[1]);
    pointsArray.push(cupVertices[1]);
    colorsArray.push(cupColors[1]);
    pointsArray.push(cupVertices[3]);
    colorsArray.push(cupColors[1]);

    pointsArray.push(cupVertices[3]);
    colorsArray.push(cupColors[0]);
    pointsArray.push(cupVertices[2]);
    colorsArray.push(cupColors[0]);
    pointsArray.push(cupVertices[0]);
    colorsArray.push(cupColors[0]);

    pointsArray.push(cupVertices[2]);
    colorsArray.push(cupColors[1]);
    pointsArray.push(cupVertices[3]);
    colorsArray.push(cupColors[1]);
    pointsArray.push(cupVertices[5]);
    colorsArray.push(cupColors[1]);

    pointsArray.push(cupVertices[5]);
    colorsArray.push(cupColors[0]);
    pointsArray.push(cupVertices[4]);
    colorsArray.push(cupColors[0]);
    pointsArray.push(cupVertices[2]);
    colorsArray.push(cupColors[0]);

    pointsArray.push(cupVertices[4]);
    colorsArray.push(cupColors[1]);
    pointsArray.push(cupVertices[5]);
    colorsArray.push(cupColors[1]);
    pointsArray.push(cupVertices[7]);
    colorsArray.push(cupColors[1]);

    pointsArray.push(cupVertices[7]);
    colorsArray.push(cupColors[0]);
    pointsArray.push(cupVertices[6]);
    colorsArray.push(cupColors[0]);
    pointsArray.push(cupVertices[4]);
    colorsArray.push(cupColors[0]);

    pointsArray.push(cupVertices[6]);
    colorsArray.push(cupColors[1]);
    pointsArray.push(cupVertices[7]);
    colorsArray.push(cupColors[1]);
    pointsArray.push(cupVertices[9]);
    colorsArray.push(cupColors[1]);

    pointsArray.push(cupVertices[9]);
    colorsArray.push(cupColors[0]);
    pointsArray.push(cupVertices[8]);
    colorsArray.push(cupColors[0]);
    pointsArray.push(cupVertices[6]);
    colorsArray.push(cupColors[0]);

    pointsArray.push(cupVertices[8]);
    colorsArray.push(cupColors[1]);
    pointsArray.push(cupVertices[9]);
    colorsArray.push(cupColors[1]);
    pointsArray.push(cupVertices[11]);
    colorsArray.push(cupColors[1]);

    pointsArray.push(cupVertices[11]);
    colorsArray.push(cupColors[0]);
    pointsArray.push(cupVertices[10]);
    colorsArray.push(cupColors[0]);
    pointsArray.push(cupVertices[8]);
    colorsArray.push(cupColors[0]);

    pointsArray.push(cupVertices[10]);
    colorsArray.push(cupColors[1]);
    pointsArray.push(cupVertices[11]);
    colorsArray.push(cupColors[1]);
    pointsArray.push(cupVertices[13]);
    colorsArray.push(cupColors[1]);

    pointsArray.push(cupVertices[13]);
    colorsArray.push(cupColors[0]);
    pointsArray.push(cupVertices[12]);
    colorsArray.push(cupColors[0]);
    pointsArray.push(cupVertices[10]);
    colorsArray.push(cupColors[0]);

    pointsArray.push(cupVertices[12]);
    colorsArray.push(cupColors[1]);
    pointsArray.push(cupVertices[13]);
    colorsArray.push(cupColors[1]);
    pointsArray.push(cupVertices[15]);
    colorsArray.push(cupColors[1]);

    pointsArray.push(cupVertices[15]);
    colorsArray.push(cupColors[0]);
    pointsArray.push(cupVertices[14]);
    colorsArray.push(cupColors[0]);
    pointsArray.push(cupVertices[12]);
    colorsArray.push(cupColors[0]);

    pointsArray.push(cupVertices[14]);
    colorsArray.push(cupColors[1]);
    pointsArray.push(cupVertices[15]);
    colorsArray.push(cupColors[1]);
    pointsArray.push(cupVertices[1]);
    colorsArray.push(cupColors[1]);

    pointsArray.push(cupVertices[1]);
    colorsArray.push(cupColors[0]);
    pointsArray.push(cupVertices[0]);
    colorsArray.push(cupColors[0]);
    pointsArray.push(cupVertices[14]);
    colorsArray.push(cupColors[0]);


}

function drawCube(){
  modelViewStack.push(modelViewMatrix);
  gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));
  gl.drawArrays( gl.TRIANGLE_FAN, 0, 24);
  modelViewMatrix = modelViewStack.pop;
  console.log(cubeVertices);
}

function drawCup(){
  modelViewStack.push(modelViewMatrix);
  gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));
  gl.drawArrays( gl.TRIANGLES, 24, 48);
  modelViewMatrix = modelViewStack.pop;
}

function scale4(a, b, c) {
    var result = mat4();
    result[0][0] = a;
    result[1][1] = b;
    result[2][2] = c;
    return result;
}

// namespace contain all the project information
var AllInfo = {

    // Camera pan control variables.
    zoomFactor : 4,
    translateX : 0,
    translateY : 0,

    // Camera rotate control variables.
    phi : 1,
    theta : 0.5,
    radius : 1,
    dr : 2.0 * Math.PI/180.0,

    // Mouse control variables
    mouseDownRight : false,
    mouseDownLeft : false,

    mousePosOnClickX : 0,
    mousePosOnClickY : 0
};

window.onload = function init() {
    canvas = document.getElementById( "gl-canvas" );

    gl = WebGLUtils.setupWebGL( canvas );
    if ( !gl ) { alert( "WebGL isn't available" ); }

    gl.viewport( 0, 0, canvas.width, canvas.height );

    gl.clearColor( 1.0, 1.0, 1.0, 1.0 );

    gl.enable(gl.DEPTH_TEST);

    //  Load shaders and initialize attribute buffers
    var program = initShaders( gl, "vertex-shader", "fragment-shader" );
    gl.useProgram( program );

    generateCube();
    generateCup();

    var cBuffer = gl.createBuffer();
    gl.bindBuffer( gl.ARRAY_BUFFER, cBuffer );
    gl.bufferData( gl.ARRAY_BUFFER, flatten(colorsArray), gl.STATIC_DRAW );

    var vColor = gl.getAttribLocation( program, "vColor" );
    gl.vertexAttribPointer( vColor, 4, gl.FLOAT, false, 0, 0 );
    gl.enableVertexAttribArray( vColor);

    var vBuffer = gl.createBuffer();
    gl.bindBuffer( gl.ARRAY_BUFFER, vBuffer );
    gl.bufferData( gl.ARRAY_BUFFER, flatten(pointsArray), gl.STATIC_DRAW );

    var vPosition = gl.getAttribLocation( program, "vPosition" );
    gl.vertexAttribPointer( vPosition, 4, gl.FLOAT, false, 0, 0 );
    gl.enableVertexAttribArray( vPosition );

    modelViewMatrixLoc = gl.getUniformLocation( program, "modelViewMatrix" );
    projectionMatrixLoc = gl.getUniformLocation( program, "projectionMatrix" );


    // Set the scroll wheel to change the zoom factor.
    document.getElementById("gl-canvas").addEventListener("wheel", function(e) {
        if (e.wheelDelta > 0) {
            AllInfo.zoomFactor = Math.max(0.1, AllInfo.zoomFactor - 0.1);
        } else {
            AllInfo.zoomFactor += 0.1;
        }
        render();
    });

    //************************************************************************************
    //* When you click a mouse button, set it so that only that button is seen as
    //* pressed in AllInfo. Then set the position. The idea behind this and the mousemove
    //* event handler's functionality is that each update we see how much the mouse moved
    //* and adjust the camera value by that amount.
    //************************************************************************************
    document.getElementById("gl-canvas").addEventListener("mousedown", function(e) {
        if (e.which == 1) {
            AllInfo.mouseDownLeft = true;
            AllInfo.mouseDownRight = false;
            AllInfo.mousePosOnClickY = e.y;
            AllInfo.mousePosOnClickX = e.x;
        } else if (e.which == 3) {
            AllInfo.mouseDownRight = true;
            AllInfo.mouseDownLeft = false;
            AllInfo.mousePosOnClickY = e.y;
            AllInfo.mousePosOnClickX = e.x;
        }
        render();
    });

    document.addEventListener("mouseup", function(e) {
        AllInfo.mouseDownLeft = false;
        AllInfo.mouseDownRight = false;
        render();
    });

    document.addEventListener("mousemove", function(e) {
        if (AllInfo.mouseDownRight) {
            AllInfo.translateX += (e.x - AllInfo.mousePosOnClickX)/30;
            AllInfo.mousePosOnClickX = e.x;

            AllInfo.translateY -= (e.y - AllInfo.mousePosOnClickY)/30;
            AllInfo.mousePosOnClickY = e.y;
        } else if (AllInfo.mouseDownLeft) {
            AllInfo.phi += (e.x - AllInfo.mousePosOnClickX)/100;
            AllInfo.mousePosOnClickX = e.x;

            AllInfo.theta += (e.y - AllInfo.mousePosOnClickY)/100;
            AllInfo.mousePosOnClickY = e.y;
        }
        render();
    });

    render();
}

var at = vec3(0, 0, 0);
var up = vec3(0, 1, 0);
var eye = vec3(2, 2, 2);
var render = function() {

    gl.clear( gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

    //Change view using mouse movements
    projectionMatrix = ortho( x_min*AllInfo.zoomFactor - AllInfo.translateX,
                              x_max*AllInfo.zoomFactor - AllInfo.translateX,
                            y_min*AllInfo.zoomFactor - AllInfo.translateY,
                              y_max*AllInfo.zoomFactor - AllInfo.translateY,
                            near, far);
    gl.uniformMatrix4fv(projectionMatrixLoc, false, flatten(projectionMatrix));

    // Setup the eye to move around different points on a sphere
    eye = vec3( AllInfo.radius*Math.cos(AllInfo.phi),
                AllInfo.radius*Math.sin(AllInfo.theta),
               AllInfo.radius*Math.sin(AllInfo.phi));


    //draw the walls and floor
    modelViewStack.push(modelViewMatrix);
    modelViewMatrix = lookAt(eye, at, up);
    modelViewMatrix = mult(modelViewMatrix, translate(-15, 0, 0));
    modelViewMatrix = mult(modelViewMatrix, scale4(0.5, 10, 15));
    gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));
    drawCube();
    modelViewMatrix = modelViewStack.pop();

    modelViewStack.push(modelViewMatrix);
    modelViewMatrix = lookAt(eye, at, up);
    modelViewMatrix = mult(modelViewMatrix, translate(0, 0, -15));
    modelViewMatrix = mult(modelViewMatrix, rotate(-90, 0, 1, 0));
    modelViewMatrix = mult(modelViewMatrix, scale4(0.5, 10, 15));
    gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));
    drawCube();
    modelViewMatrix = modelViewStack.pop();

    modelViewStack.push(modelViewMatrix);
    modelViewMatrix = lookAt(eye, at, up);
    modelViewMatrix = mult(modelViewMatrix, translate(0, -9.5, 0));
    modelViewMatrix = mult(modelViewMatrix, scale4(15, 0.5, 15));
    gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));
    drawCube();
    modelViewMatrix = modelViewStack.pop();

    modelViewStack.push(modelViewMatrix);
    modelViewMatrix = lookAt(eye, at, up);
    modelViewMatrix = mult(modelViewMatrix, translate(0, 0, -13));
    modelViewMatrix = mult(modelViewMatrix, scale4(0.75, 10, 2));
    gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));
    drawCube();
    modelViewMatrix = modelViewStack.pop();

    //draw cup
    modelViewStack.push(modelViewMatrix);
    modelViewMatrix = lookAt(eye, at, up);
    modelViewMatrix = mult(modelViewMatrix, scale4(0.75, 2, 1));
    gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));
    drawCup();
    modelViewMatrix = modelViewStack.pop();
console.log(pointsArray);
}
