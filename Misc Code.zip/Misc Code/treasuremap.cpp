/*Jaylon Atkins
CSCI 3110-001 (your section #)
Project #05
Due: 03/25/21
*/

#include "treasuremap.h"
using namespace std;

int main()
{
TreasureMap::TreasureMap(std::ifstream&)
    {
    
    }

TreasureMap::PrintMap()
    {

    }   

TreasureMap::FindTreasure(int, int, bool&)
    {

    }

TreasureMap::getMove(char)
    {
        
        int row_offset = -1, col_offset = 1;
        std::pair<int,int> move = std::make_pair(row_offset, col_offset);
    }

}
